var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => ClaudeForObsidianPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian4 = require("obsidian");
var import_child_process2 = require("child_process");
var fs3 = __toESM(require("fs"));

// src/settings.ts
var import_obsidian = require("obsidian");
var DEFAULT_SETTINGS = {
  claudeBinaryPath: "/opt/homebrew/bin/claude",
  model: "",
  effort: "high",
  permissionMode: "acceptEdits",
  activeSessionId: null,
  sessionLabels: {},
  bypassPermissionsConfirmed: false
};
var MODEL_OPTIONS = [
  { id: "claude-opus-4-7", label: "Opus 4.7" },
  { id: "opus[1m]", label: "Opus 4.7", sublabel: "1M context" },
  { id: "claude-sonnet-4-6", label: "Sonnet 4.6" },
  { id: "sonnet[1m]", label: "Sonnet 4.6", sublabel: "1M context" },
  { id: "claude-haiku-4-5", label: "Haiku 4.5" },
  { id: "claude-opus-4-6", label: "Opus 4.6", sublabel: "Legacy", legacy: true }
];
var EFFORT_OPTIONS = [
  { id: "low", label: "Low" },
  { id: "medium", label: "Medium" },
  { id: "high", label: "High" },
  { id: "xhigh", label: "Extra high" },
  { id: "max", label: "Max" }
];
var MODE_OPTIONS = [
  { id: "default", label: "Ask permissions" },
  { id: "acceptEdits", label: "Accept edits" },
  { id: "plan", label: "Plan mode" },
  { id: "auto", label: "Auto mode" },
  { id: "bypassPermissions", label: "Bypass permissions" }
];
var ClaudeForObsidianSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    new import_obsidian.Setting(containerEl).setName("Claude binary path").setDesc("Absolute path to the claude CLI. Auto-detected on first run via `which claude`. Override here if detection picked the wrong location or failed.").addText(
      (text) => text.setPlaceholder("/opt/homebrew/bin/claude").setValue(this.plugin.settings.claudeBinaryPath).onChange(async (value) => {
        this.plugin.settings.claudeBinaryPath = value.trim();
        await this.plugin.saveSettings();
      })
    );
  }
};

// src/view.ts
var import_obsidian3 = require("obsidian");
var fs2 = __toESM(require("fs"));
var path = __toESM(require("path"));
var os = __toESM(require("os"));

// src/claude-client.ts
var import_child_process = require("child_process");
var VALID_EFFORTS = new Set(EFFORT_OPTIONS.map((e) => e.id));
var HOOK_CALLBACK_ID = "cfob-pretooluse";
var ClaudeSession = class {
  constructor(opts) {
    this.opts = opts;
    this.child = null;
    this.initSent = false;
    this.alive = false;
    this.stdoutBuffer = "";
    this.pendingControlResponses = /* @__PURE__ */ new Map();
  }
  /** True if a subprocess is currently running for this session. */
  get isAlive() {
    return this.alive;
  }
  /** Send a user message to the CLI. Spawns the subprocess on first
   *  call. Idempotent across multiple turns within the same chat. */
  sendMessage(prompt) {
    if (!this.alive) {
      this.spawnChild();
      if (!this.alive)
        return;
    }
    if (!this.initSent) {
      this.writeStdin(this.initializeRequest());
      this.initSent = true;
    }
    const userMsg = {
      type: "user",
      message: { role: "user", content: prompt },
      parent_tool_use_id: null
    };
    this.writeStdin(userMsg);
  }
  /** Send an `interrupt` control_request to abort the current turn
   *  without killing the subprocess. The CLI honours this by stopping
   *  the in-flight model call and emitting a `result` event. */
  cancel() {
    if (!this.alive)
      return;
    this.writeStdin({
      type: "control_request",
      request_id: this.makeRequestId(),
      request: { subtype: "interrupt" }
    });
  }
  /** Close stdin so the CLI exits cleanly. Triggered on chat switch,
   *  new chat, delete-active-chat, panel close, plugin unload. */
  end() {
    if (this.child && this.child.stdin && !this.child.stdin.destroyed) {
      try {
        this.child.stdin.end();
      } catch {
      }
    }
  }
  /** Hard kill via SIGTERM. Used when end() doesn't bring the child
   *  down (or when we don't want to wait). */
  kill() {
    this.end();
    if (this.child && !this.child.killed) {
      try {
        this.child.kill("SIGTERM");
      } catch {
      }
    }
  }
  /** Send a structured control_response back to the CLI's stdin to
   *  settle the PreToolUse hook callback. */
  respondPermission(requestId, decision) {
    if (!this.alive)
      return;
    const response = decision.behavior === "allow" ? {
      decision: "approve",
      hookSpecificOutput: {
        hookEventName: "PreToolUse",
        permissionDecision: "allow",
        permissionDecisionReason: "User approved via Claude for Obsidian",
        updatedInput: decision.updatedInput
      }
    } : {
      decision: "block",
      hookSpecificOutput: {
        hookEventName: "PreToolUse",
        permissionDecision: "deny",
        permissionDecisionReason: decision.message ?? "User denied via Claude for Obsidian"
      }
    };
    this.writeStdin({
      type: "control_response",
      response: {
        subtype: "success",
        request_id: requestId,
        response
      }
    });
  }
  /** Ask the CLI for its current context-window usage snapshot. The
   *  CLI replies with a `control_response` carrying the totalTokens,
   *  maxTokens, percentage, and per-category breakdown. Used by the
   *  context-window popup; the ring battery between turns stays on
   *  the cheap per-turn `tokensFromUsage` accumulator. */
  getContextUsage() {
    if (!this.alive) {
      return Promise.reject(new Error("Session not alive"));
    }
    const requestId = this.makeRequestId();
    return new Promise((resolve, reject) => {
      this.pendingControlResponses.set(requestId, { resolve, reject });
      this.writeStdin({
        type: "control_request",
        request_id: requestId,
        request: { subtype: "get_context_usage" }
      });
    });
  }
  // ---------- internals ----------
  spawnChild() {
    const args = [
      "--print",
      "--input-format",
      "stream-json",
      "--output-format",
      "stream-json",
      "--verbose",
      "--permission-mode",
      this.opts.settings.permissionMode
    ];
    if (this.opts.settings.model) {
      args.push("--model", this.opts.settings.model);
    }
    if (this.opts.settings.effort && VALID_EFFORTS.has(this.opts.settings.effort)) {
      args.push("--effort", this.opts.settings.effort);
    }
    if (this.opts.resumeSessionId) {
      args.push("--resume", this.opts.resumeSessionId);
    }
    const env = { ...process.env };
    const pathAdditions = ["/opt/homebrew/bin", "/usr/local/bin"];
    const existingPath = env.PATH ?? "";
    const pathParts = existingPath.split(":").filter(Boolean);
    for (const p of pathAdditions) {
      if (!pathParts.includes(p))
        pathParts.unshift(p);
    }
    env.PATH = pathParts.join(":");
    let child;
    try {
      child = (0, import_child_process.spawn)(this.opts.settings.claudeBinaryPath, args, {
        cwd: this.opts.cwd,
        env
      });
    } catch (e) {
      this.opts.onEvent({ kind: "error", message: `Failed to spawn claude: ${e.message}` });
      this.opts.onEvent({ kind: "exit", code: null });
      return;
    }
    this.child = child;
    this.alive = true;
    child.stdout.on("data", (chunk) => {
      this.stdoutBuffer += chunk.toString("utf8");
      let nl;
      while ((nl = this.stdoutBuffer.indexOf("\n")) !== -1) {
        const line = this.stdoutBuffer.slice(0, nl).trim();
        this.stdoutBuffer = this.stdoutBuffer.slice(nl + 1);
        if (!line)
          continue;
        this.dispatchLine(line);
      }
    });
    child.stderr.on("data", (chunk) => {
      const text = chunk.toString("utf8");
      for (const line of text.split("\n")) {
        if (line.trim())
          this.opts.onEvent({ kind: "stderr", line });
      }
    });
    child.on("error", (err) => {
      this.opts.onEvent({ kind: "error", message: err.message });
    });
    child.on("close", (code) => {
      if (this.stdoutBuffer.trim())
        this.dispatchLine(this.stdoutBuffer.trim());
      this.alive = false;
      for (const { reject } of this.pendingControlResponses.values()) {
        reject(new Error("Session closed before response"));
      }
      this.pendingControlResponses.clear();
      this.opts.onEvent({ kind: "exit", code });
    });
  }
  /** Build the initialize control_request that registers the PreToolUse
   *  hook so the CLI routes permission decisions back to us. Without
   *  this the CLI auto-denies any tool call that would otherwise prompt
   *  the user (confirmed against the binary on 2026-05-11). */
  initializeRequest() {
    return {
      type: "control_request",
      request_id: this.makeRequestId(),
      request: {
        subtype: "initialize",
        hooks: {
          PreToolUse: [
            {
              matcher: "",
              hookCallbackIds: [HOOK_CALLBACK_ID],
              timeout: 6e5
            }
          ]
        }
      }
    };
  }
  writeStdin(payload) {
    if (!this.child || !this.child.stdin || this.child.stdin.destroyed)
      return;
    try {
      this.child.stdin.write(JSON.stringify(payload) + "\n");
    } catch (e) {
      this.opts.onEvent({ kind: "error", message: `Failed to write to CLI: ${e.message}` });
    }
  }
  makeRequestId() {
    return `cfob-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  }
  dispatchLine(line) {
    let evt;
    try {
      evt = JSON.parse(line);
    } catch {
      this.opts.onEvent({ kind: "stderr", line: `[non-json] ${line}` });
      return;
    }
    const type = evt.type;
    if (type === "system") {
      this.opts.onEvent({ kind: "system", raw: evt });
      return;
    }
    if (type === "assistant" && evt.message?.content) {
      for (const block of evt.message.content) {
        if (block.type === "text") {
          this.opts.onEvent({ kind: "assistant-text", text: block.text });
        } else if (block.type === "tool_use") {
          this.opts.onEvent({
            kind: "tool-use",
            id: typeof block.id === "string" ? block.id : null,
            name: block.name,
            input: block.input
          });
        }
      }
      return;
    }
    if (type === "user" && evt.message?.content) {
      for (const block of evt.message.content) {
        if (block.type === "tool_result") {
          const content = typeof block.content === "string" ? block.content : JSON.stringify(block.content);
          this.opts.onEvent({
            kind: "tool-result",
            toolUseId: typeof block.tool_use_id === "string" ? block.tool_use_id : null,
            content,
            isError: !!block.is_error
          });
        }
      }
      return;
    }
    if (type === "control_response") {
      const requestId = typeof evt.response?.request_id === "string" ? evt.response.request_id : null;
      if (requestId) {
        const pending = this.pendingControlResponses.get(requestId);
        if (pending) {
          this.pendingControlResponses.delete(requestId);
          if (evt.response.subtype === "success") {
            pending.resolve(evt.response.response);
          } else {
            pending.reject(
              new Error(
                typeof evt.response.error === "string" ? evt.response.error : "control_request failed"
              )
            );
          }
        }
      }
      return;
    }
    if (type === "control_request" && evt.request?.subtype === "hook_callback") {
      const req = evt.request;
      const input = req.input ?? {};
      if (input.hook_event_name === "PreToolUse") {
        this.opts.onEvent({
          kind: "permission-request",
          requestId: typeof evt.request_id === "string" ? evt.request_id : "",
          toolUseId: typeof input.tool_use_id === "string" ? input.tool_use_id : "",
          toolName: typeof input.tool_name === "string" ? input.tool_name : "",
          input: input.tool_input ?? {}
        });
      } else {
        this.writeStdin({
          type: "control_response",
          response: { subtype: "success", request_id: evt.request_id, response: {} }
        });
      }
      return;
    }
    if (type === "result") {
      this.opts.onEvent({ kind: "result", raw: evt });
      return;
    }
  }
};

// src/diff.ts
var splitLines = (s) => {
  if (s === "")
    return [];
  return s.split("\n");
};
function lineDiff(oldText, newText) {
  const a = splitLines(oldText);
  const b = splitLines(newText);
  const m = a.length;
  const n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i2 = m - 1; i2 >= 0; i2--) {
    for (let j2 = n - 1; j2 >= 0; j2--) {
      if (a[i2] === b[j2])
        dp[i2][j2] = dp[i2 + 1][j2 + 1] + 1;
      else
        dp[i2][j2] = Math.max(dp[i2 + 1][j2], dp[i2][j2 + 1]);
    }
  }
  const ops = [];
  let i = 0;
  let j = 0;
  while (i < m && j < n) {
    if (a[i] === b[j]) {
      ops.push({ kind: "eq", text: a[i], oldLine: i + 1, newLine: j + 1 });
      i++;
      j++;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      ops.push({ kind: "del", text: a[i], oldLine: i + 1 });
      i++;
    } else {
      ops.push({ kind: "add", text: b[j], newLine: j + 1 });
      j++;
    }
  }
  while (i < m) {
    ops.push({ kind: "del", text: a[i], oldLine: i + 1 });
    i++;
  }
  while (j < n) {
    ops.push({ kind: "add", text: b[j], newLine: j + 1 });
    j++;
  }
  return ops;
}
function summarizeDiff(ops) {
  let add = 0;
  let del = 0;
  for (const op of ops) {
    if (op.kind === "add")
      add++;
    else if (op.kind === "del")
      del++;
  }
  return { add, del };
}
function renderDiff(host, ops, opts = {}) {
  const gutter = opts.gutter ?? true;
  const oldOff = opts.oldLineOffset ?? 0;
  const newOff = opts.newLineOffset ?? 0;
  const block = host.createDiv({ cls: "cfo-tool-diff" });
  for (const op of ops) {
    const row = block.createDiv({ cls: `cfo-tool-diff-line cfo-tool-diff-line-${op.kind}` });
    if (gutter) {
      const oldGut = row.createSpan({ cls: "cfo-tool-diff-gutter cfo-tool-diff-gutter-old" });
      oldGut.setText(op.oldLine != null ? String(op.oldLine + oldOff) : "");
      const newGut = row.createSpan({ cls: "cfo-tool-diff-gutter cfo-tool-diff-gutter-new" });
      newGut.setText(op.newLine != null ? String(op.newLine + newOff) : "");
    }
    const marker = op.kind === "add" ? "+" : op.kind === "del" ? "-" : " ";
    row.createSpan({ cls: "cfo-tool-diff-marker", text: marker });
    row.createSpan({ cls: "cfo-tool-diff-text", text: op.text });
  }
}

// src/chat-export.ts
var fs = __toESM(require("fs"));
function exportSession(opts) {
  let raw;
  try {
    raw = fs.readFileSync(opts.jsonlPath, "utf8");
  } catch {
    return null;
  }
  const turns = [];
  let createdISO = "";
  const datesSeen = /* @__PURE__ */ new Set();
  for (const line of raw.split("\n")) {
    if (!line.trim())
      continue;
    let evt;
    try {
      evt = JSON.parse(line);
    } catch {
      continue;
    }
    if (typeof evt.timestamp === "string" && !createdISO)
      createdISO = evt.timestamp;
    if (typeof evt.timestamp === "string") {
      const d = evt.timestamp.slice(0, 10);
      if (d)
        datesSeen.add(d);
    }
    if (evt.type === "user" && evt.message?.content) {
      const content = evt.message.content;
      if (typeof content === "string") {
        if (isSkillInjection(content))
          continue;
        turns.push({
          role: "user",
          timestamp: evt.timestamp || "",
          text: content
        });
      } else if (Array.isArray(content)) {
        const texts = [];
        for (const block of content) {
          if (block?.type === "text" && typeof block.text === "string") {
            texts.push(block.text);
          }
        }
        if (texts.length) {
          const joined = texts.join("\n");
          if (isSkillInjection(joined))
            continue;
          turns.push({
            role: "user",
            timestamp: evt.timestamp || "",
            text: joined
          });
        }
      }
      continue;
    }
    if (evt.type === "assistant" && evt.message?.content) {
      let text = "";
      for (const block of evt.message.content) {
        if (block?.type === "text" && typeof block.text === "string") {
          text += block.text;
        }
      }
      turns.push({
        role: "assistant",
        timestamp: evt.timestamp || "",
        text
      });
      continue;
    }
  }
  if (turns.length === 0)
    return null;
  const created = createdISO ? createdISO.slice(0, 10) : todayDate();
  const stamp = createdISO ? localStamp(createdISO) : nowStamp();
  const firstUser = turns.find((t) => t.role === "user")?.text ?? "";
  const slug = slugify(firstUser);
  const filename = slug ? `Claude Chat ${created} ${stamp} ${slug}.md` : `Claude Chat ${created} ${stamp}.md`;
  const dateRange = Array.from(datesSeen).sort().reverse();
  const body = renderBody({
    turns,
    dateRange
  });
  return { filename, body };
}
function renderBody(args) {
  const front = [
    "---",
    "doctype: chat-transcript",
    "agent: Claude",
    "date_range:",
    ...args.dateRange.map((d) => `  - "[[${d}]]"`),
    "---",
    ""
  ].join("\n");
  const sections = [];
  let i = 0;
  while (i < args.turns.length) {
    const t = args.turns[i];
    if (t.role === "user") {
      sections.push(`## ${formatTime(t.timestamp)} - You

${wrapUserContent(t.text.trim())}
`);
      i++;
      continue;
    }
    const parts = [];
    const headingTime = formatTime(t.timestamp);
    while (i < args.turns.length && args.turns[i].role === "assistant") {
      const at = args.turns[i];
      if (at.text.trim())
        parts.push(demoteHeadings(at.text.trim()));
      i++;
    }
    sections.push(`## ${headingTime} - Claude

${parts.join("\n\n")}
`);
  }
  return front + sections.join("\n");
}
function wrapUserContent(body) {
  if (looksDangerous(body)) {
    let longest = 0;
    const matches = body.match(/`+/g);
    if (matches) {
      for (const m of matches)
        if (m.length > longest)
          longest = m.length;
    }
    const fence = "`".repeat(Math.max(3, longest + 1));
    return `${fence}markdown
${body}
${fence}`;
  }
  return demoteHeadings(body);
}
function looksDangerous(body) {
  if (/<[a-zA-Z][\w-]*(?:\s|>|\/)/.test(body))
    return true;
  const fenceCount = (body.match(/^```/gm) || []).length;
  if (fenceCount % 2 !== 0)
    return true;
  if (/\S{300,}/.test(body))
    return true;
  if (body.length > 4e3)
    return true;
  return false;
}
function demoteHeadings(body) {
  const headingRe = /^(#{1,6})\s+/gm;
  let shallowest = 7;
  for (const m of body.matchAll(headingRe)) {
    const level = m[1].length;
    if (level < shallowest)
      shallowest = level;
  }
  if (shallowest >= 3 || shallowest === 7)
    return body;
  const shift = 3 - shallowest;
  return body.replace(headingRe, (_, hashes) => {
    const newLevel = Math.min(6, hashes.length + shift);
    return "#".repeat(newLevel) + " ";
  });
}
function formatTime(iso) {
  if (!iso)
    return "??:??";
  const d = new Date(iso);
  if (isNaN(d.getTime()))
    return "??:??";
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function localStamp(iso) {
  const d = new Date(iso);
  if (isNaN(d.getTime()))
    return nowStamp();
  return `${pad(d.getHours())}${pad(d.getMinutes())}`;
}
function nowStamp() {
  const d = /* @__PURE__ */ new Date();
  return `${pad(d.getHours())}${pad(d.getMinutes())}`;
}
function todayDate() {
  const d = /* @__PURE__ */ new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function pad(n) {
  return n < 10 ? `0${n}` : String(n);
}
function isSkillInjection(text) {
  return text.trimStart().startsWith("Base directory for this skill:");
}
function slugify(s) {
  const cleaned = s.toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
  return cleaned.slice(0, 40).replace(/-$/, "");
}

// src/wikilink-suggest.ts
var WikilinkSuggest = class {
  constructor(app, textarea) {
    this.app = app;
    this.textarea = textarea;
    this.popup = null;
    this.items = [];
    this.selected = 0;
    this.triggerStart = -1;
    this.rowEls = [];
    this.destroyed = false;
    this.onInput = () => {
      this.refresh();
    };
    this.onBlur = () => {
      setTimeout(() => this.close(), 100);
    };
    this.onKeydown = (e) => {
      if (!this.popup)
        return;
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        this.close();
        return;
      }
      if (e.key === "ArrowDown") {
        e.preventDefault();
        e.stopPropagation();
        this.move(1);
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        e.stopPropagation();
        this.move(-1);
        return;
      }
      if (e.key === "Enter" || e.key === "Tab") {
        if (this.items.length > 0) {
          e.preventDefault();
          e.stopPropagation();
          this.commit(this.items[this.selected]);
        }
        return;
      }
    };
    this.textarea.addEventListener("input", this.onInput);
    this.textarea.addEventListener("keydown", this.onKeydown, true);
    this.textarea.addEventListener("blur", this.onBlur);
  }
  destroy() {
    this.destroyed = true;
    this.textarea.removeEventListener("input", this.onInput);
    this.textarea.removeEventListener("keydown", this.onKeydown, true);
    this.textarea.removeEventListener("blur", this.onBlur);
    this.close();
  }
  isOpen() {
    return this.popup !== null;
  }
  refresh() {
    const trigger = this.detectTrigger();
    if (!trigger) {
      this.close();
      return;
    }
    this.triggerStart = trigger.start;
    const matches = this.search(trigger.query);
    if (matches.length === 0) {
      this.close();
      return;
    }
    this.items = matches;
    this.selected = 0;
    this.render();
  }
  detectTrigger() {
    const value = this.textarea.value;
    const caret = this.textarea.selectionStart ?? 0;
    const head = value.slice(0, caret);
    const open = head.lastIndexOf("[[");
    if (open === -1)
      return null;
    const between = head.slice(open + 2);
    if (between.includes("]]") || between.includes("\n"))
      return null;
    return { start: open + 2, query: between };
  }
  search(query) {
    const files = this.app.vault.getMarkdownFiles();
    const q = query.toLowerCase();
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const file of files) {
      const basename2 = file.basename;
      const aliases = this.aliasesFor(file);
      const candidates = [
        { display: basename2, alias: null }
      ];
      for (const a of aliases)
        candidates.push({ display: a, alias: a });
      for (const c of candidates) {
        if (q.length > 0 && !c.display.toLowerCase().includes(q))
          continue;
        const key = `${file.path}::${c.alias ?? ""}`;
        if (seen.has(key))
          continue;
        seen.add(key);
        out.push({
          display: c.display,
          alias: c.alias,
          insert: c.alias ? `${basename2}|${c.alias}` : basename2,
          file,
          mtime: file.stat.mtime
        });
      }
    }
    out.sort((a, b) => {
      const aLower = a.display.toLowerCase();
      const bLower = b.display.toLowerCase();
      const aStarts = aLower.startsWith(q);
      const bStarts = bLower.startsWith(q);
      if (aStarts !== bStarts)
        return aStarts ? -1 : 1;
      if (b.mtime !== a.mtime)
        return b.mtime - a.mtime;
      return aLower.localeCompare(bLower);
    });
    return out.slice(0, 50);
  }
  aliasesFor(file) {
    const cache = this.app.metadataCache.getFileCache(file);
    const raw = cache?.frontmatter?.aliases;
    if (!raw)
      return [];
    if (Array.isArray(raw))
      return raw.filter((x) => typeof x === "string");
    if (typeof raw === "string")
      return [raw];
    return [];
  }
  render() {
    if (!this.popup) {
      this.popup = this.textarea.ownerDocument.body.createDiv({ cls: "cfo-wikilink-suggest" });
    }
    this.popup.empty();
    this.rowEls = [];
    for (let i = 0; i < this.items.length; i++) {
      const item = this.items[i];
      const row = this.popup.createDiv({ cls: "cfo-wikilink-suggest-row" });
      if (i === this.selected)
        row.addClass("cfo-wikilink-suggest-row-active");
      const display = row.createSpan({ cls: "cfo-wikilink-suggest-display", text: item.display });
      if (item.alias) {
        display.createSpan({ cls: "cfo-wikilink-suggest-alias-mark", text: " \u21A6 " });
        display.createSpan({ cls: "cfo-wikilink-suggest-base", text: item.file.basename });
      }
      row.addEventListener("mousedown", (e) => {
        e.preventDefault();
        this.commit(item);
      });
      this.rowEls.push(row);
    }
    this.position();
  }
  position() {
    if (!this.popup)
      return;
    const rect = this.textarea.getBoundingClientRect();
    const win = this.textarea.ownerDocument.defaultView ?? window;
    const popupHeight = Math.min(this.popup.offsetHeight || 240, 240);
    const spaceAbove = rect.top;
    const placeAbove = spaceAbove > popupHeight + 16;
    if (placeAbove) {
      this.popup.style.top = `${rect.top - popupHeight - 4}px`;
    } else {
      this.popup.style.top = `${rect.bottom + 4}px`;
    }
    this.popup.style.left = `${rect.left}px`;
    this.popup.style.maxWidth = `${Math.min(rect.width, 480)}px`;
  }
  move(delta) {
    if (this.items.length === 0)
      return;
    this.selected = (this.selected + delta + this.items.length) % this.items.length;
    for (let i = 0; i < this.rowEls.length; i++) {
      this.rowEls[i].toggleClass("cfo-wikilink-suggest-row-active", i === this.selected);
    }
    const active = this.rowEls[this.selected];
    if (active)
      active.scrollIntoView({ block: "nearest" });
  }
  commit(item) {
    if (this.destroyed)
      return;
    const value = this.textarea.value;
    const caret = this.textarea.selectionStart ?? 0;
    const before = value.slice(0, this.triggerStart);
    const after = value.slice(caret);
    const insert = `${item.insert}]]`;
    const next = `${before}${insert}${after}`;
    const cursor = before.length + insert.length;
    this.textarea.value = next;
    this.textarea.setSelectionRange(cursor, cursor);
    this.close();
    this.textarea.dispatchEvent(new Event("input", { bubbles: true }));
  }
  close() {
    if (!this.popup)
      return;
    this.popup.remove();
    this.popup = null;
    this.items = [];
    this.rowEls = [];
    this.selected = 0;
    this.triggerStart = -1;
  }
};

// src/slash-suggest.ts
var SlashSuggest = class {
  constructor(textarea, provider) {
    this.textarea = textarea;
    this.provider = provider;
    this.popup = null;
    this.items = [];
    this.selected = 0;
    this.triggerStart = -1;
    this.rowEls = [];
    this.destroyed = false;
    this.onInput = () => {
      this.refresh();
    };
    this.onBlur = () => {
      setTimeout(() => this.close(), 100);
    };
    this.onKeydown = (e) => {
      if (!this.popup)
        return;
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        this.close();
        return;
      }
      if (e.key === "ArrowDown") {
        e.preventDefault();
        e.stopPropagation();
        this.move(1);
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        e.stopPropagation();
        this.move(-1);
        return;
      }
      if (e.key === "Enter" || e.key === "Tab") {
        if (this.items.length > 0) {
          e.preventDefault();
          e.stopPropagation();
          this.commit(this.items[this.selected]);
        }
        return;
      }
    };
    this.textarea.addEventListener("input", this.onInput);
    this.textarea.addEventListener("keydown", this.onKeydown, true);
    this.textarea.addEventListener("blur", this.onBlur);
  }
  destroy() {
    this.destroyed = true;
    this.textarea.removeEventListener("input", this.onInput);
    this.textarea.removeEventListener("keydown", this.onKeydown, true);
    this.textarea.removeEventListener("blur", this.onBlur);
    this.close();
  }
  isOpen() {
    return this.popup !== null;
  }
  refresh() {
    const trigger = this.detectTrigger();
    if (!trigger) {
      this.close();
      return;
    }
    this.triggerStart = trigger.start;
    const matches = this.search(trigger.query);
    if (matches.length === 0) {
      this.close();
      return;
    }
    this.items = matches;
    this.selected = 0;
    this.render();
  }
  // Fires only when the message begins with a slash command token:
  // optional leading whitespace, a single "/", then a run with no
  // whitespace and no second "/". This keeps it from triggering on
  // file paths (src/foo) typed mid-message.
  detectTrigger() {
    const value = this.textarea.value;
    const caret = this.textarea.selectionStart ?? 0;
    const head = value.slice(0, caret);
    const m = head.match(/^\s*\/([^\s/]*)$/);
    if (!m)
      return null;
    return { start: head.indexOf("/"), query: m[1] };
  }
  search(query) {
    const q = query.toLowerCase();
    const all = this.provider();
    const out = all.filter(
      (c) => q.length === 0 || c.name.toLowerCase().includes(q) || c.description.toLowerCase().includes(q)
    );
    out.sort((a, b) => {
      const aStarts = a.name.toLowerCase().startsWith(q);
      const bStarts = b.name.toLowerCase().startsWith(q);
      if (aStarts !== bStarts)
        return aStarts ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    return out.slice(0, 50);
  }
  render() {
    if (!this.popup) {
      this.popup = this.textarea.ownerDocument.body.createDiv({ cls: "cfo-wikilink-suggest" });
    }
    this.popup.empty();
    this.rowEls = [];
    for (let i = 0; i < this.items.length; i++) {
      const item = this.items[i];
      const row = this.popup.createDiv({ cls: "cfo-wikilink-suggest-row" });
      if (i === this.selected)
        row.addClass("cfo-wikilink-suggest-row-active");
      const display = row.createSpan({ cls: "cfo-wikilink-suggest-display", text: `/${item.name}` });
      if (item.description) {
        display.createSpan({ cls: "cfo-wikilink-suggest-alias-mark", text: "  " });
        display.createSpan({ cls: "cfo-wikilink-suggest-base", text: item.description });
      }
      row.addEventListener("mousedown", (e) => {
        e.preventDefault();
        this.commit(item);
      });
      this.rowEls.push(row);
    }
    this.position();
  }
  position() {
    if (!this.popup)
      return;
    const rect = this.textarea.getBoundingClientRect();
    const popupHeight = Math.min(this.popup.offsetHeight || 240, 240);
    const placeAbove = rect.top > popupHeight + 16;
    if (placeAbove) {
      this.popup.style.top = `${rect.top - popupHeight - 4}px`;
    } else {
      this.popup.style.top = `${rect.bottom + 4}px`;
    }
    this.popup.style.left = `${rect.left}px`;
    this.popup.style.maxWidth = `${Math.min(rect.width, 480)}px`;
  }
  move(delta) {
    if (this.items.length === 0)
      return;
    this.selected = (this.selected + delta + this.items.length) % this.items.length;
    for (let i = 0; i < this.rowEls.length; i++) {
      this.rowEls[i].toggleClass("cfo-wikilink-suggest-row-active", i === this.selected);
    }
    const active = this.rowEls[this.selected];
    if (active)
      active.scrollIntoView({ block: "nearest" });
  }
  commit(item) {
    if (this.destroyed)
      return;
    const value = this.textarea.value;
    const caret = this.textarea.selectionStart ?? 0;
    const before = value.slice(0, this.triggerStart);
    const after = value.slice(caret);
    const insert = `/${item.name} `;
    this.textarea.value = `${before}${insert}${after}`;
    const cursor = before.length + insert.length;
    this.textarea.setSelectionRange(cursor, cursor);
    this.close();
    this.textarea.dispatchEvent(new Event("input", { bubbles: true }));
  }
  close() {
    if (!this.popup)
      return;
    this.popup.remove();
    this.popup = null;
    this.items = [];
    this.rowEls = [];
    this.selected = 0;
    this.triggerStart = -1;
  }
};

// src/model-popup.ts
var import_obsidian2 = require("obsidian");
function openModelPopup(ctx) {
  const doc = ctx.triggerEl.ownerDocument;
  const win = doc.defaultView;
  doc.querySelectorAll(".cfo-model-popup").forEach((el) => el.remove());
  const popup = doc.body.createDiv({ cls: "cfo-model-popup" });
  const rect = ctx.triggerEl.getBoundingClientRect();
  popup.style.bottom = `${win.innerHeight - rect.top + 6}px`;
  popup.style.right = `${Math.max(8, win.innerWidth - rect.right)}px`;
  ctx.triggerEl.addClass("cfo-btn-active");
  popup.createDiv({ cls: "cfo-model-popup-section-label", text: "Models" });
  for (const m of MODEL_OPTIONS) {
    const row = popup.createDiv({ cls: "cfo-model-popup-row" });
    if (ctx.settings.model === m.id)
      row.addClass("cfo-model-popup-row-active");
    const label = row.createSpan({ cls: "cfo-model-popup-row-label" });
    label.createSpan({ text: m.label });
    if (m.sublabel) {
      label.createSpan({
        cls: m.legacy ? "cfo-model-popup-sublabel-legacy" : "cfo-model-popup-sublabel",
        text: m.sublabel
      });
    }
    if (ctx.settings.model === m.id) {
      const check = row.createSpan({ cls: "cfo-model-popup-check" });
      (0, import_obsidian2.setIcon)(check, "check");
    }
    row.onclick = async (e) => {
      e.stopPropagation();
      await ctx.onModelChange(m.id);
      ctx.triggerEl.removeClass("cfo-btn-active");
      popup.remove();
    };
  }
  popup.createDiv({ cls: "cfo-model-popup-divider" });
  popup.createDiv({ cls: "cfo-model-popup-section-label", text: "Effort" });
  for (const e of EFFORT_OPTIONS) {
    const row = popup.createDiv({ cls: "cfo-model-popup-row" });
    if (ctx.settings.effort === e.id)
      row.addClass("cfo-model-popup-row-active");
    row.createSpan({ cls: "cfo-model-popup-row-label", text: e.label });
    if (ctx.settings.effort === e.id) {
      const check = row.createSpan({ cls: "cfo-model-popup-check" });
      (0, import_obsidian2.setIcon)(check, "check");
    }
    row.onclick = async (evt) => {
      evt.stopPropagation();
      await ctx.onEffortChange(e.id);
      ctx.triggerEl.removeClass("cfo-btn-active");
      popup.remove();
    };
  }
  const dismiss = (e) => {
    if (popup.contains(e.target))
      return;
    if (ctx.triggerEl.contains(e.target))
      return;
    ctx.triggerEl.removeClass("cfo-btn-active");
    popup.remove();
    doc.removeEventListener("mousedown", dismiss, true);
    doc.removeEventListener("keydown", esc, true);
  };
  const esc = (e) => {
    if (e.key === "Escape") {
      ctx.triggerEl.removeClass("cfo-btn-active");
      popup.remove();
      doc.removeEventListener("mousedown", dismiss, true);
      doc.removeEventListener("keydown", esc, true);
    }
  };
  setTimeout(() => {
    doc.addEventListener("mousedown", dismiss, true);
    doc.addEventListener("keydown", esc, true);
  }, 0);
}

// src/tool-renderers.ts
var basename = (p) => {
  if (typeof p !== "string" || !p)
    return String(p ?? "");
  const slash = p.lastIndexOf("/");
  return slash === -1 ? p : p.slice(slash + 1);
};
var vaultRelative = (p, cwd) => {
  if (typeof p !== "string")
    return String(p ?? "");
  if (cwd && p.startsWith(cwd + "/"))
    return p.slice(cwd.length + 1);
  return p;
};
var lineCount = (s) => {
  if (!s)
    return 0;
  const trimmed = s.endsWith("\n") ? s.slice(0, -1) : s;
  return trimmed.split("\n").length;
};
var truncate = (s, max) => {
  if (s.length <= max)
    return s;
  return s.slice(0, max) + "\u2026";
};
var firstLine = (s) => {
  if (!s)
    return "";
  const idx = s.indexOf("\n");
  return idx === -1 ? s : s.slice(0, idx);
};
var renderEdit = (input, _result, ctx) => {
  const filePath = typeof input?.file_path === "string" ? input.file_path : "";
  const oldStr = typeof input?.old_string === "string" ? input.old_string : "";
  const newStr = typeof input?.new_string === "string" ? input.new_string : "";
  const name = filePath ? basename(filePath) : "(no path)";
  const rel = filePath ? vaultRelative(filePath, ctx.cwd) : "";
  const oldSingle = !oldStr.includes("\n");
  const newSingle = !newStr.includes("\n");
  const shortish = oldStr.length <= 80 && newStr.length <= 80;
  if (oldSingle && newSingle && shortish && oldStr && newStr) {
    return {
      verb: "Edited",
      target: name,
      flat: `${rel || name}: ${truncate(oldStr, 80)} \u2192 ${truncate(newStr, 80)}`
    };
  }
  const ops = lineDiff(oldStr, newStr);
  const { add, del } = summarizeDiff(ops);
  return {
    verb: "Edited",
    target: name,
    addCount: add,
    delCount: del,
    expandDefault: true,
    expand: (host) => {
      renderDiff(host, ops);
    }
  };
};
var renderWrite = (input, _result, ctx) => {
  const filePath = typeof input?.file_path === "string" ? input.file_path : "";
  const content = typeof input?.content === "string" ? input.content : "";
  const name = filePath ? basename(filePath) : "(no path)";
  const lines = lineCount(content);
  return {
    verb: "Wrote",
    target: name,
    addCount: lines,
    expandDefault: true,
    expand: (host) => {
      const ops = lineDiff("", content);
      renderDiff(host, ops);
    }
  };
};
var renderRead = (input, _result, ctx) => {
  const filePath = typeof input?.file_path === "string" ? input.file_path : "";
  const name = filePath ? vaultRelative(filePath, ctx.cwd) : "";
  return { verb: "Read", target: name };
};
var renderBash = (input, result) => {
  const cmd = typeof input?.command === "string" ? input.command : "";
  const desc = typeof input?.description === "string" ? input.description : "";
  let suffix = "";
  if (result && !result.isError) {
    const head = firstLine(result.content).trim();
    if (head)
      suffix = ` \u2192 ${truncate(head, 80)}`;
  }
  if (result?.isError)
    suffix = " (error)";
  return {
    verb: "Ran",
    target: desc ? `${desc}` : truncate(cmd, 120),
    suffix
  };
};
var renderGlob = (input, result) => {
  const pattern = typeof input?.pattern === "string" ? input.pattern : "";
  let suffix = "";
  if (result && !result.isError) {
    const trimmed = result.content.trim();
    if (trimmed) {
      const n = trimmed.split(/\r?\n/).filter(Boolean).length;
      suffix = ` (${n} match${n === 1 ? "" : "es"})`;
    } else {
      suffix = " (0 matches)";
    }
  }
  return { verb: "Globbed", target: pattern, suffix };
};
var renderGrep = (input, result) => {
  const pattern = typeof input?.pattern === "string" ? input.pattern : "";
  const path2 = typeof input?.path === "string" ? input.path : "";
  const target = path2 ? `${pattern} in ${basename(path2)}` : pattern;
  let suffix = "";
  if (result && !result.isError) {
    const trimmed = result.content.trim();
    if (trimmed) {
      const n = trimmed.split(/\r?\n/).filter(Boolean).length;
      suffix = ` (${n} hit${n === 1 ? "" : "s"})`;
    }
  }
  return { verb: "Grepped", target, suffix };
};
var renderTask = (input) => {
  const desc = typeof input?.description === "string" ? input.description : "";
  const prompt = typeof input?.prompt === "string" ? input.prompt : "";
  const target = desc || truncate(firstLine(prompt), 120);
  return { verb: "Delegated", target };
};
var renderWebFetch = (input) => {
  const url = typeof input?.url === "string" ? input.url : "";
  return { verb: "Fetched", target: url };
};
var renderWebSearch = (input) => {
  const query = typeof input?.query === "string" ? input.query : "";
  return { verb: "Searched", target: query };
};
var renderSkill = (input) => {
  const skill = typeof input?.skill === "string" ? input.skill : "";
  return { verb: "Loaded", target: skill ? `${skill} skill` : "skill" };
};
var renderTodoWrite = (input) => {
  const todos = Array.isArray(input?.todos) ? input.todos : [];
  return {
    verb: "Planned",
    target: todos.length === 1 ? "1 todo" : `${todos.length} todos`
  };
};
var renderNotebookEdit = (input, _r, ctx) => {
  const path2 = typeof input?.notebook_path === "string" ? input.notebook_path : "";
  return { verb: "Edited", target: path2 ? basename(path2) : "" };
};
var renderToolSearch = (input) => {
  const query = typeof input?.query === "string" ? input.query : "";
  return { verb: "Searched tools", target: truncate(query, 80) };
};
var renderDefault = (input) => {
  let summary;
  try {
    summary = typeof input === "object" ? JSON.stringify(input) : String(input);
  } catch {
    summary = String(input);
  }
  return { verb: "", target: truncate(summary, 240) };
};
var REGISTRY = {
  Edit: renderEdit,
  Write: renderWrite,
  Read: renderRead,
  Bash: renderBash,
  Glob: renderGlob,
  Grep: renderGrep,
  Task: renderTask,
  WebFetch: renderWebFetch,
  WebSearch: renderWebSearch,
  Skill: renderSkill,
  TodoWrite: renderTodoWrite,
  NotebookEdit: renderNotebookEdit,
  ToolSearch: renderToolSearch
};
function getToolRenderer(name) {
  return REGISTRY[name] ?? renderDefault;
}
function renderToolRow(name, input, result, ctx) {
  return getToolRenderer(name)(input, result, ctx);
}

// src/view.ts
function relativeTime(ts) {
  const diff = Date.now() - ts;
  if (diff < 0)
    return "now";
  const m = Math.floor(diff / 6e4);
  if (m < 1)
    return "now";
  if (m < 60)
    return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24)
    return `${h}h`;
  const d = Math.floor(h / 24);
  if (d < 7)
    return `${d}d`;
  const w = Math.floor(d / 7);
  if (w < 5)
    return `${w}w`;
  const mo = Math.floor(d / 30);
  if (mo < 12)
    return `${mo}mo`;
  const y = Math.floor(d / 365);
  return `${y}y`;
}
var CLAUDE_FOR_OBSIDIAN_VIEW = "claude-for-obsidian-view";
var REVEAL_BASE_CPS = 720;
var REVEAL_BURST_THRESHOLD = 800;
var REVEAL_BURST_MULTIPLIER = 3;
var THINKING_VERBS = [
  "Foraging",
  "Frolicking",
  "Gallivanting",
  "Weeding",
  "Harvesting",
  "Encouraging",
  "Gathering",
  "Mulching",
  "Composting",
  "Pruning",
  "Sowing",
  "Divining",
  "Listening",
  "Wandering",
  "Pottering",
  "Tending",
  "Kindling",
  "Casting",
  "Dismantling",
  "Kneading",
  "Ploughing",
  "Kissing",
  "Hugging",
  "Feeling",
  "Revolting",
  "Strumming",
  "Plucking",
  "Smiling",
  "Singing"
];
var THINKING_ROTATE_MS = 3e3;
function contextWindowForModel(modelId) {
  const id = (modelId ?? "").toLowerCase();
  if (id.includes("[1m]"))
    return 1e6;
  return 2e5;
}
function extractFirstUserText(filePath) {
  let lines;
  try {
    lines = fs2.readFileSync(filePath, "utf8").split("\n").slice(0, 50);
  } catch {
    return null;
  }
  for (const line of lines) {
    if (!line.trim())
      continue;
    let evt;
    try {
      evt = JSON.parse(line);
    } catch {
      continue;
    }
    if (evt.type !== "user")
      continue;
    const content = evt.message?.content;
    if (typeof content === "string") {
      const trimmed = content.trim();
      if (trimmed)
        return trimmed;
      continue;
    }
    if (Array.isArray(content)) {
      for (const block of content) {
        if (block?.type === "text" && typeof block.text === "string") {
          const trimmed = block.text.trim();
          if (trimmed)
            return trimmed;
        }
      }
    }
  }
  return null;
}
var BASH_SAFE_COMMANDS = /* @__PURE__ */ new Set([
  // Identity / system info
  "date",
  "echo",
  "pwd",
  "whoami",
  "hostname",
  "uname",
  "which",
  "type",
  "command",
  "where",
  "env",
  "printenv",
  "locale",
  "id",
  "groups",
  // File reading
  "cat",
  "head",
  "tail",
  "less",
  "more",
  "wc",
  "file",
  "stat",
  "du",
  "df",
  "basename",
  "dirname",
  "realpath",
  "readlink",
  // Listing
  "ls",
  "tree",
  "find",
  // Search (read-only)
  "grep",
  "egrep",
  "fgrep",
  "rg",
  "ag",
  // Process info (read-only)
  "ps",
  "pgrep",
  "jobs",
  "uptime",
  // Misc read-only
  "true",
  "false",
  "test"
]);
var GIT_SAFE_SUBCOMMANDS = /* @__PURE__ */ new Set([
  "status",
  "log",
  "diff",
  "show",
  "branch",
  "remote",
  "ls-files",
  "ls-tree",
  "rev-parse",
  "blame",
  "describe",
  "tag",
  "stash",
  "shortlog",
  "reflog"
]);
var BypassConfirmModal = class extends import_obsidian3.Modal {
  constructor(app, workspacePath) {
    super(app);
    this.workspacePath = workspacePath;
    this.settled = false;
  }
  /** Open the modal and resolve when the user picks a button or
   *  dismisses. Await this from the caller. */
  prompt() {
    return new Promise((resolve) => {
      this.resolver = resolve;
      this.open();
    });
  }
  onOpen() {
    const { contentEl, titleEl } = this;
    this.modalEl.addClass("cfo-bypass-modal");
    titleEl.setText("Bypass all permissions?");
    contentEl.empty();
    contentEl.createEl("p", {
      cls: "cfo-bypass-body",
      text: "Claude will read, edit, and execute files without asking \u2014 including potentially destructive commands. Only use this in isolated or disposable environments."
    });
    contentEl.createDiv({ cls: "cfo-bypass-path", text: this.workspacePath });
    contentEl.createDiv({
      cls: "cfo-bypass-footnote",
      text: "You won't be asked again for this workspace."
    });
    const footer = contentEl.createDiv({ cls: "cfo-bypass-footer" });
    const cancelBtn = footer.createEl("button", { cls: "cfo-bypass-btn" });
    cancelBtn.setText("Cancel");
    cancelBtn.onclick = () => {
      this.settle(false);
    };
    const okBtn = footer.createEl("button", {
      cls: "cfo-bypass-btn cfo-bypass-btn-primary mod-cta"
    });
    okBtn.setText("Bypass permissions");
    okBtn.onclick = () => {
      this.settle(true);
    };
    setTimeout(() => cancelBtn.focus(), 0);
  }
  onClose() {
    this.settle(false);
    this.contentEl.empty();
  }
  settle(result) {
    if (this.settled)
      return;
    this.settled = true;
    if (this.resolver)
      this.resolver(result);
    this.close();
  }
};
function hasBashSafetyOverride(command) {
  if (!command || typeof command !== "string")
    return false;
  const trimmed = command.trim();
  if (!trimmed)
    return false;
  if (/[><|;&`$()]/.test(trimmed))
    return true;
  if (/^sudo\b/.test(trimmed))
    return true;
  if (/^find\b/.test(trimmed) && /\s-(delete|exec|execdir|ok|okdir)\b/.test(trimmed))
    return true;
  return false;
}
function isSafeBashCommand(command) {
  if (!command || typeof command !== "string")
    return false;
  const trimmed = command.trim();
  if (!trimmed)
    return false;
  if (hasBashSafetyOverride(trimmed))
    return false;
  const head = trimmed.split(/\s+/)[0];
  if (head === "git") {
    const sub = trimmed.split(/\s+/)[1];
    if (!sub)
      return false;
    if (sub === "config")
      return /\s--(get|list|get-all|get-regexp)\b/.test(trimmed);
    return GIT_SAFE_SUBCOMMANDS.has(sub);
  }
  return BASH_SAFE_COMMANDS.has(head);
}
function generateRuleSuggestions(toolName, input, cwd) {
  const suggestions = [];
  const relativize = (p) => {
    if (cwd && p.startsWith(cwd + "/"))
      return p.slice(cwd.length + 1);
    if (cwd && p === cwd)
      return ".";
    return p;
  };
  const push = (pattern, scope, displayPattern) => {
    const realDisplayPattern = displayPattern ?? pattern;
    const display = pattern === null ? toolName : `${toolName}(${realDisplayPattern})`;
    if (suggestions.some((s) => s.rule.display === display))
      return;
    suggestions.push({ rule: { toolName, pattern, display }, scope });
  };
  if (toolName === "Bash") {
    const cmd = typeof input?.command === "string" ? input.command.trim() : "";
    if (cmd) {
      const head = cmd.split(/\s+/)[0];
      push(cmd, "this");
      if (head)
        push(`${head} *`, "some");
    }
    push(null, "all");
    return suggestions;
  }
  if (toolName === "Edit" || toolName === "Write" || toolName === "NotebookEdit") {
    const filePath = typeof input?.file_path === "string" ? input.file_path : typeof input?.notebook_path === "string" ? input.notebook_path : "";
    if (filePath) {
      push(filePath, "this", relativize(filePath));
      const slash = filePath.lastIndexOf("/");
      if (slash > 0) {
        const folder = filePath.slice(0, slash);
        const folderRel = relativize(folder);
        push(`${folder}/**`, "some", `${folderRel === "." ? "" : folderRel + "/"}**`);
      }
    }
    push(null, "all");
    return suggestions;
  }
  if (toolName === "Read" || toolName === "Glob" || toolName === "Grep") {
    const p = typeof input?.file_path === "string" ? input.file_path : typeof input?.path === "string" ? input.path : "";
    if (p) {
      push(p, "this", relativize(p));
      const slash = p.lastIndexOf("/");
      if (slash > 0) {
        const folder = p.slice(0, slash);
        const folderRel = relativize(folder);
        push(`${folder}/**`, "some", `${folderRel === "." ? "" : folderRel + "/"}**`);
      }
    }
    push(null, "all");
    return suggestions;
  }
  if (toolName === "WebFetch") {
    const url = typeof input?.url === "string" ? input.url : "";
    if (url) {
      push(url, "this");
      try {
        const u = new URL(url);
        push(`${u.protocol}//${u.host}/*`, "some");
      } catch {
      }
    }
    push(null, "all");
    return suggestions;
  }
  push(null, "all");
  return suggestions;
}
function scopeDescription(scope, toolName) {
  if (scope === "this") {
    if (toolName === "Bash")
      return "this exact command";
    if (toolName === "WebFetch" || toolName === "WebSearch")
      return "this exact URL";
    return "this exact path";
  }
  if (scope === "some") {
    if (toolName === "Bash")
      return "any command with this prefix";
    if (toolName === "WebFetch")
      return "any URL on this host";
    return "anything in this folder";
  }
  if (toolName === "Bash")
    return "any shell command";
  if (toolName === "WebFetch")
    return "any web fetch";
  if (toolName === "WebSearch")
    return "any web search";
  return `any ${toolName.toLowerCase()}`;
}
function matchesAllowRule(toolName, input, rules) {
  for (const rule of rules) {
    if (rule.toolName !== toolName)
      continue;
    if (rule.pattern === null)
      return true;
    if (toolName === "Bash") {
      const cmd = typeof input?.command === "string" ? input.command.trim() : "";
      if (!cmd)
        continue;
      if (rule.pattern.endsWith(" *")) {
        const prefix = rule.pattern.slice(0, -2);
        if (cmd === prefix || cmd.startsWith(prefix + " "))
          return true;
      } else if (cmd === rule.pattern) {
        return true;
      }
      continue;
    }
    if (toolName === "Edit" || toolName === "Write" || toolName === "NotebookEdit" || toolName === "Read" || toolName === "Glob" || toolName === "Grep") {
      const p = typeof input?.file_path === "string" ? input.file_path : typeof input?.notebook_path === "string" ? input.notebook_path : typeof input?.path === "string" ? input.path : "";
      if (!p)
        continue;
      if (rule.pattern.endsWith("/**")) {
        const prefix = rule.pattern.slice(0, -3);
        if (p === prefix || p.startsWith(prefix + "/"))
          return true;
      } else if (p === rule.pattern) {
        return true;
      }
      continue;
    }
    if (toolName === "WebFetch") {
      const url = typeof input?.url === "string" ? input.url : "";
      if (!url)
        continue;
      if (rule.pattern.endsWith("/*")) {
        const prefix = rule.pattern.slice(0, -2);
        if (url.startsWith(prefix + "/") || url === prefix)
          return true;
      } else if (url === rule.pattern) {
        return true;
      }
      continue;
    }
  }
  return false;
}
var _ClaudeForObsidianView = class _ClaudeForObsidianView extends import_obsidian3.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    // One subprocess per chat (v0.6.0). Stays alive across multiple
    // user-message turns so in-memory state (CronCreate schedulers,
    // watchers) survives between turns. End() is called on chat switch,
    // new chat, delete-active-chat, and panel close.
    this.currentSession = null;
    // True while a user-message turn is in flight (user message sent,
    // result event not yet received). Used to gate UI affordances that
    // require a quiescent session.
    this.turnBusy = false;
    this.currentAssistant = null;
    this.renderComponent = new import_obsidian3.Component();
    this.activeSessionId = null;
    this.pendingTitle = null;
    this.sessionTokensUsed = 0;
    this.lastStderr = null;
    this.lastDateKey = null;
    this.wikilinkSuggest = null;
    this.slashSuggest = null;
    this.slashCommandsCache = null;
    this.pendingTools = /* @__PURE__ */ new Map();
    this.currentToolGroup = null;
    // Permission dialog state — single instance anchored above the input
    // stack. Pending requests beyond the active one queue FIFO.
    this.permissionDialogEl = null;
    this.permissionQueue = [];
    this.activePermissionRequest = null;
    this.permissionKeyHandler = null;
    // Session-scoped user allow-rules accumulated via the dialog's
    // "Allow always" menu. Cleared on chat switch / new chat / panel
    // close. Matches the native CLI's per-session rule storage.
    this.allowRules = [];
    // Per-turn wrapper for everything Claude emits in a single agent turn:
    // narration prose, tool groups, final prose. The CLAUDE header sits
    // once at the top of this wrapper. Reset to null when a user message
    // lands (closes the turn) or `closeClaudeTurn` is called explicitly.
    this.currentClaudeTurn = null;
    this.trailingThinkingEl = null;
    this.trailingThinkingTimer = null;
  }
  getViewType() {
    return CLAUDE_FOR_OBSIDIAN_VIEW;
  }
  getDisplayText() {
    return "Claude for Obsidian";
  }
  getIcon() {
    return "bot";
  }
  async onOpen() {
    const root = this.containerEl.children[1];
    root.empty();
    root.addClass("claude-for-obsidian-view");
    const headerRow = root.createDiv({ cls: "cfo-header-row" });
    this.chatTitleEl = headerRow.createEl("button", { cls: "cfo-chat-title-tab" });
    this.chatTitleEl.title = "Chat history, rename, delete";
    this.chatTitleEl.onclick = (evt) => this.toggleHistoryMenu(evt);
    this.refreshChatTitle();
    headerRow.createDiv({ cls: "cfo-header-spacer" });
    const saveBtn = headerRow.createEl("button", { cls: "cfo-header-btn" });
    (0, import_obsidian3.setIcon)(saveBtn, "download");
    saveBtn.title = "Save chat to vault";
    saveBtn.onclick = () => this.saveChatToVault();
    this.outputEl = root.createDiv({ cls: "cfo-output" });
    this.activeSessionId = this.plugin.settings.activeSessionId ?? null;
    if (this.activeSessionId) {
      this.replaySession(this.activeSessionId);
    } else {
      this.renderSplash();
    }
    this.refreshChatTitle();
    this.permissionDialogEl = root.createDiv({ cls: "cfo-permission-dialog cfo-permission-dialog-hidden" });
    const inputStack = root.createDiv({ cls: "cfo-input-stack" });
    this.statusEl = inputStack.createDiv({ cls: "cfo-status" });
    const textBox = inputStack.createDiv({ cls: "cfo-textbox" });
    this.inputEl = textBox.createEl("textarea", { cls: "cfo-input" });
    this.inputEl.placeholder = "Type / for commands, [[ for wikilinks";
    this.inputEl.rows = 1;
    this.autosizeInput();
    this.sendStopBtn = textBox.createEl("button", { cls: "cfo-send-inline" });
    (0, import_obsidian3.setIcon)(this.sendStopBtn, "corner-down-left");
    const footerNav = inputStack.createDiv({ cls: "cfo-footer-nav" });
    this.editsBtn = footerNav.createEl("button", { cls: "cfo-edits-btn" });
    this.editsBtn.onclick = () => this.toggleModePopup();
    this.refreshEditsBtn();
    const plusBtn = footerNav.createEl("button", { cls: "cfo-footer-btn" });
    (0, import_obsidian3.setIcon)(plusBtn, "plus");
    plusBtn.title = "Add (coming soon)";
    plusBtn.onclick = () => this.togglePlusMenu(plusBtn);
    footerNav.createDiv({ cls: "cfo-footer-spacer" });
    this.batteryEl = footerNav.createEl("button", { cls: "cfo-battery" });
    this.batteryEl.onclick = () => this.toggleContextPopup();
    this.renderBattery();
    this.modelBtn = footerNav.createEl("button", { cls: "cfo-model-btn" });
    this.modelBtn.onclick = () => this.toggleModelMenu();
    this.refreshModelBtn();
    this.sendStopBtn.title = "Send (Enter)";
    this.sendStopBtn.onclick = () => this.toggleSendStop();
    this.inputEl.addEventListener("input", () => this.autosizeInput());
    this.inputEl.addEventListener("keydown", (e) => {
      if (this.wikilinkSuggest?.isOpen() || this.slashSuggest?.isOpen())
        return;
      if (e.key === "Enter" && !e.shiftKey && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        this.toggleSendStop();
      } else if (e.key === "Escape" && this.turnBusy) {
        e.preventDefault();
        this.cancel();
      }
    });
    this.wikilinkSuggest = new WikilinkSuggest(this.app, this.inputEl);
    this.slashSuggest = new SlashSuggest(this.inputEl, () => this.getSlashCommands());
    this.renderComponent.load();
  }
  async onClose() {
    if (this.currentSession) {
      this.currentSession.kill();
      this.currentSession = null;
    }
    this.turnBusy = false;
    this.stopTrailingThinking();
    if (this.wikilinkSuggest) {
      this.wikilinkSuggest.destroy();
      this.wikilinkSuggest = null;
    }
    if (this.slashSuggest) {
      this.slashSuggest.destroy();
      this.slashSuggest = null;
    }
    this.renderComponent.unload();
  }
  autosizeInput() {
    if (!this.inputEl)
      return;
    const cs = getComputedStyle(this.inputEl);
    const lineHeight = parseFloat(cs.lineHeight) || 20;
    const paddingY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
    const borderY = parseFloat(cs.borderTopWidth) + parseFloat(cs.borderBottomWidth);
    const maxH = lineHeight * 10 + paddingY + borderY;
    this.inputEl.style.height = "auto";
    const desired = this.inputEl.scrollHeight;
    this.inputEl.style.height = Math.min(desired, maxH) + "px";
    this.inputEl.style.overflowY = desired > maxH ? "auto" : "hidden";
  }
  resolveCwd() {
    const adapter = this.app.vault.adapter;
    if (typeof adapter.getBasePath === "function")
      return adapter.getBasePath();
    return process.cwd();
  }
  vaultName() {
    return this.app.vault.getName();
  }
  // ---------- slash commands ----------
  /** Memoised per panel-open. Skills and custom commands don't change
   *  within a panel session; rediscovery happens on next panel open. */
  getSlashCommands() {
    if (this.slashCommandsCache)
      return this.slashCommandsCache;
    this.slashCommandsCache = this.discoverSlashCommands();
    return this.slashCommandsCache;
  }
  /** Enumerate the reachable slash surface: skills (resolved by the
   *  CLI via /skill-name) and custom command markdown files. Vault-local
   *  definitions override the home-level ones of the same name. */
  discoverSlashCommands() {
    const cwd = this.resolveCwd();
    const home = os.homedir();
    const byName = /* @__PURE__ */ new Map();
    for (const base of [home, cwd]) {
      const skillsDir = path.join(base, ".claude", "skills");
      let entries = [];
      try {
        entries = fs2.readdirSync(skillsDir);
      } catch {
        continue;
      }
      for (const entry of entries) {
        const skillMd = path.join(skillsDir, entry, "SKILL.md");
        let text;
        try {
          if (!fs2.statSync(path.join(skillsDir, entry)).isDirectory())
            continue;
          text = fs2.readFileSync(skillMd, "utf8");
        } catch {
          continue;
        }
        const fm = this.parseFrontmatter(text);
        const name = (fm.name || entry).trim();
        byName.set(name, {
          name,
          description: (fm.description || "").trim(),
          kind: "skill"
        });
      }
    }
    for (const base of [home, cwd]) {
      const cmdDir = path.join(base, ".claude", "commands");
      let entries = [];
      try {
        entries = fs2.readdirSync(cmdDir);
      } catch {
        continue;
      }
      for (const entry of entries) {
        if (!entry.endsWith(".md"))
          continue;
        const name = entry.slice(0, -3);
        let text = "";
        try {
          text = fs2.readFileSync(path.join(cmdDir, entry), "utf8");
        } catch {
          continue;
        }
        const fm = this.parseFrontmatter(text);
        let desc = (fm.description || "").trim();
        if (!desc) {
          const body = this.stripFrontmatter(text).trim();
          desc = body.split("\n")[0]?.replace(/^#+\s*/, "").slice(0, 120) ?? "";
        }
        byName.set(name, { name, description: desc, kind: "command" });
      }
    }
    return Array.from(byName.values()).sort((a, b) => a.name.localeCompare(b.name));
  }
  stripFrontmatter(text) {
    if (!text.startsWith("---"))
      return text;
    const end = text.indexOf("\n---", 3);
    if (end === -1)
      return text;
    const after = text.indexOf("\n", end + 1);
    return after === -1 ? "" : text.slice(after + 1);
  }
  parseFrontmatter(text) {
    if (!text.startsWith("---"))
      return {};
    const end = text.indexOf("\n---", 3);
    if (end === -1)
      return {};
    const block = text.slice(3, end);
    const out = {};
    const lines = block.split("\n");
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].match(/^(name|description)\s*:\s*(.*)$/);
      if (!m)
        continue;
      const key = m[1];
      let val = m[2].trim();
      if (/^[>|][+-]?$/.test(val)) {
        const parts = [];
        for (let j = i + 1; j < lines.length; j++) {
          if (/^\S/.test(lines[j]))
            break;
          if (lines[j].trim() === "")
            continue;
          parts.push(lines[j].trim());
        }
        val = parts.join(" ");
      }
      out[key] = val.replace(/^["']|["']$/g, "");
    }
    return out;
  }
  /** Expand a custom command into its prompt body before the message
   *  goes to the CLI. Skills pass through unchanged ( the CLI resolves
   *  /skill-name itself ); unknown /tokens also pass through so the CLI
   *  can surface its own error. $ARGUMENTS gets the full argument
   *  string, $1..$9 the positional args. */
  expandSlashCommand(input) {
    const m = input.match(/^\/([^\s/]+)\s*([\s\S]*)$/);
    if (!m)
      return input;
    const name = m[1];
    const argStr = m[2].trim();
    const cmd = this.getSlashCommands().find((c) => c.name === name && c.kind === "command");
    if (!cmd)
      return input;
    const cwd = this.resolveCwd();
    const home = os.homedir();
    let text = null;
    for (const base of [cwd, home]) {
      try {
        text = fs2.readFileSync(path.join(base, ".claude", "commands", `${name}.md`), "utf8");
        break;
      } catch {
      }
    }
    if (text === null)
      return input;
    let body = this.stripFrontmatter(text).trim();
    if (!body)
      return input;
    const positional = argStr.length > 0 ? argStr.split(/\s+/) : [];
    body = body.replace(/\$ARGUMENTS/g, argStr);
    body = body.replace(/\$([1-9])/g, (_, d) => positional[Number(d) - 1] ?? "");
    return body;
  }
  /** Plus-menu entry point: focus the input and open the palette by
   *  seeding a leading "/" when the message doesn't already start one. */
  openSlashPalette() {
    if (!this.inputEl)
      return;
    this.inputEl.focus();
    const v = this.inputEl.value;
    if (!/^\s*\//.test(v)) {
      this.inputEl.value = `/${v}`;
      this.inputEl.setSelectionRange(1, 1);
    }
    this.inputEl.dispatchEvent(new Event("input", { bubbles: true }));
  }
  setTitleText(text) {
    if (!this.chatTitleEl)
      return;
    this.chatTitleEl.empty();
    this.chatTitleEl.createSpan({ cls: "cfo-chat-title-label", text });
    const chevron = this.chatTitleEl.createSpan({ cls: "cfo-chat-title-chevron" });
    (0, import_obsidian3.setIcon)(chevron, "chevron-down");
  }
  refreshChatTitle() {
    if (!this.chatTitleEl)
      return;
    const id = this.activeSessionId;
    if (!id) {
      if (this.pendingTitle) {
        this.setTitleText(this.pendingTitle);
        this.chatTitleEl.toggleClass("cfo-chat-title-empty", false);
      } else {
        this.setTitleText("New chat");
        this.chatTitleEl.toggleClass("cfo-chat-title-empty", true);
      }
      return;
    }
    this.chatTitleEl.toggleClass("cfo-chat-title-empty", false);
    const custom = this.plugin.settings.sessionLabels[id];
    if (custom) {
      this.setTitleText(custom);
      return;
    }
    const filePath = this.findSessionFile(id);
    if (filePath) {
      const extracted = extractFirstUserText(filePath);
      if (extracted) {
        this.setTitleText(extracted);
        return;
      }
    }
    if (this.pendingTitle) {
      this.setTitleText(this.pendingTitle);
      return;
    }
    this.setTitleText("(untitled)");
  }
  projectsRoot() {
    return path.join(os.homedir(), ".claude", "projects");
  }
  encodedCwd() {
    return this.resolveCwd().replace(/[^A-Za-z0-9]/g, "-");
  }
  listSessions() {
    const root = this.projectsRoot();
    const dirPath = path.join(root, this.encodedCwd());
    let files;
    try {
      files = fs2.readdirSync(dirPath).filter((f) => f.endsWith(".jsonl"));
    } catch {
      return [];
    }
    const summaries = [];
    for (const file of files) {
      const fullPath = path.join(dirPath, file);
      const id = file.replace(/\.jsonl$/, "");
      let stat;
      try {
        stat = fs2.statSync(fullPath);
      } catch {
        continue;
      }
      const label = extractFirstUserText(fullPath);
      const custom = this.plugin.settings.sessionLabels[id];
      if (!label && !custom)
        continue;
      const finalLabel = custom || label;
      const truncated = finalLabel.length > 40 ? finalLabel.slice(0, 40) + "\u2026" : finalLabel;
      summaries.push({ id, label: truncated, timestamp: stat.mtimeMs });
    }
    summaries.sort((a, b) => b.timestamp - a.timestamp);
    return summaries;
  }
  toggleHistoryMenu(evt) {
    const existing = this.containerEl.ownerDocument.querySelector(".cfo-history-popup");
    if (existing) {
      this.chatTitleEl.removeClass("cfo-btn-active");
      existing.remove();
      return;
    }
    this.openHistoryMenu(evt);
  }
  openHistoryMenu(evt) {
    const doc = this.containerEl.ownerDocument;
    doc.querySelectorAll(".cfo-history-popup").forEach((el) => el.remove());
    const sessions = this.listSessions();
    const popup = doc.body.createDiv({ cls: "cfo-history-popup" });
    const target = evt.currentTarget;
    const rect = target.getBoundingClientRect();
    popup.style.top = `${rect.bottom + 4}px`;
    popup.style.left = `${rect.left}px`;
    const newChatRow = popup.createDiv({ cls: "cfo-history-new" });
    const newChatIcon = newChatRow.createSpan({ cls: "cfo-history-new-icon" });
    (0, import_obsidian3.setIcon)(newChatIcon, "plus");
    newChatRow.createSpan({ cls: "cfo-history-new-label", text: "New chat" });
    newChatRow.onclick = () => {
      this.chatTitleEl.removeClass("cfo-btn-active");
      popup.remove();
      this.newChat();
    };
    const searchWrap = popup.createDiv({ cls: "cfo-history-search" });
    const searchIcon = searchWrap.createSpan({ cls: "cfo-history-search-icon" });
    (0, import_obsidian3.setIcon)(searchIcon, "search");
    const searchInput = searchWrap.createEl("input", {
      cls: "cfo-history-search-input",
      attr: { type: "text", placeholder: "Search sessions\u2026" }
    });
    const list = popup.createDiv({ cls: "cfo-history-list" });
    const render = (filter) => {
      list.empty();
      const f = filter.trim().toLowerCase();
      const filtered = f ? sessions.filter((s) => (this.sessionLabel(s) || s.id).toLowerCase().includes(f)) : sessions;
      if (filtered.length === 0) {
        list.createDiv({ cls: "cfo-history-empty", text: "No sessions" });
        return;
      }
      for (const s of filtered) {
        const row = list.createDiv({ cls: "cfo-history-row" });
        if (s.id === this.activeSessionId)
          row.addClass("cfo-history-row-active");
        const label = row.createDiv({ cls: "cfo-history-label" });
        label.setText(this.sessionLabel(s));
        const time = row.createDiv({ cls: "cfo-history-time" });
        time.setText(relativeTime(s.timestamp));
        const actions = row.createDiv({ cls: "cfo-history-actions" });
        const renameBtn = actions.createEl("button", { cls: "cfo-history-action" });
        (0, import_obsidian3.setIcon)(renameBtn, "pencil");
        renameBtn.title = "Rename";
        renameBtn.onclick = (e) => {
          e.stopPropagation();
          this.beginRename(row, label, s.id);
        };
        const trashBtn = actions.createEl("button", { cls: "cfo-history-action" });
        (0, import_obsidian3.setIcon)(trashBtn, "trash-2");
        trashBtn.title = "Delete";
        trashBtn.onclick = (e) => {
          e.stopPropagation();
          this.confirmDelete(s.id, () => {
            const idx = sessions.indexOf(s);
            if (idx >= 0)
              sessions.splice(idx, 1);
            render(searchInput.value);
          });
        };
        row.onclick = () => {
          this.chatTitleEl.removeClass("cfo-btn-active");
          popup.remove();
          this.switchToSession(s.id);
        };
      }
    };
    render("");
    searchInput.addEventListener("input", () => render(searchInput.value));
    searchInput.focus();
    this.chatTitleEl.addClass("cfo-btn-active");
    const dismiss = (e) => {
      if (popup.contains(e.target))
        return;
      if (this.chatTitleEl.contains(e.target))
        return;
      this.chatTitleEl.removeClass("cfo-btn-active");
      popup.remove();
      doc.removeEventListener("mousedown", dismiss, true);
      doc.removeEventListener("keydown", escDismiss, true);
    };
    const escDismiss = (e) => {
      if (e.key === "Escape") {
        this.chatTitleEl.removeClass("cfo-btn-active");
        popup.remove();
        doc.removeEventListener("mousedown", dismiss, true);
        doc.removeEventListener("keydown", escDismiss, true);
      }
    };
    setTimeout(() => {
      doc.addEventListener("mousedown", dismiss, true);
      doc.addEventListener("keydown", escDismiss, true);
    }, 0);
  }
  sessionLabel(s) {
    return this.plugin.settings.sessionLabels[s.id] || s.label || "(untitled)";
  }
  beginRename(row, labelEl, id) {
    const current = this.plugin.settings.sessionLabels[id] || labelEl.textContent || "";
    const input = document.createElement("input");
    input.type = "text";
    input.value = current;
    input.className = "cfo-history-rename-input";
    labelEl.replaceWith(input);
    input.focus();
    input.select();
    const commit = () => {
      const next = input.value.trim();
      if (next && next !== current) {
        this.plugin.settings.sessionLabels[id] = next;
        this.plugin.saveSettings();
      } else if (!next) {
        delete this.plugin.settings.sessionLabels[id];
        this.plugin.saveSettings();
      }
      const newLabel = document.createElement("div");
      newLabel.className = "cfo-history-label";
      newLabel.textContent = next || row.dataset.fallbackLabel || "(untitled)";
      input.replaceWith(newLabel);
      this.notifyRename(id);
    };
    input.addEventListener("blur", commit);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        input.blur();
      } else if (e.key === "Escape") {
        e.preventDefault();
        const restored = document.createElement("div");
        restored.className = "cfo-history-label";
        restored.textContent = current;
        input.replaceWith(restored);
      }
      e.stopPropagation();
    });
  }
  confirmDelete(id, after) {
    const isActive = id === this.activeSessionId;
    const filePath = this.findSessionFile(id);
    if (!filePath) {
      new import_obsidian3.Notice("Session file not found.");
      return;
    }
    if (!confirm("Delete this chat? This cannot be undone."))
      return;
    try {
      fs2.unlinkSync(filePath);
    } catch (e) {
      new import_obsidian3.Notice(`Could not delete: ${e.message}`);
      return;
    }
    delete this.plugin.settings.sessionLabels[id];
    this.plugin.saveSettings();
    if (isActive) {
      this.newChat();
    }
    after();
  }
  // Refresh chat title when a rename commits.
  notifyRename(id) {
    if (id === this.activeSessionId)
      this.refreshChatTitle();
  }
  switchToSession(id) {
    if (this.turnBusy) {
      new import_obsidian3.Notice("Cannot switch chats while a run is in progress.");
      return;
    }
    this.endSession();
    this.activeSessionId = id;
    this.pendingTitle = null;
    this.plugin.settings.activeSessionId = id;
    this.plugin.saveSettings();
    this.outputEl.empty();
    this.currentClaudeTurn = null;
    this.currentToolGroup = null;
    this.currentAssistant = null;
    this.sessionTokensUsed = 0;
    this.lastDateKey = null;
    this.renderBattery();
    this.replaySession(id);
    this.refreshChatTitle();
    this.clearStatus();
  }
  replaySession(id) {
    const filePath = this.findSessionFile(id);
    if (!filePath)
      return;
    this.clearSplash();
    let raw;
    try {
      raw = fs2.readFileSync(filePath, "utf8");
    } catch {
      return;
    }
    let lastTokenTotal = 0;
    let pendingAssistantText = "";
    let pendingAssistantOpen = false;
    let pendingAssistantWhen = /* @__PURE__ */ new Date();
    let replayGroup = null;
    const toolResultsById = /* @__PURE__ */ new Map();
    for (const line of raw.split("\n")) {
      if (!line.trim())
        continue;
      let evt;
      try {
        evt = JSON.parse(line);
      } catch {
        continue;
      }
      if (evt.type !== "user" || !evt.message?.content)
        continue;
      const content = evt.message.content;
      if (!Array.isArray(content))
        continue;
      for (const block of content) {
        if (block?.type !== "tool_result")
          continue;
        const tid = typeof block.tool_use_id === "string" ? block.tool_use_id : null;
        if (!tid)
          continue;
        const c = typeof block.content === "string" ? block.content : JSON.stringify(block.content);
        toolResultsById.set(tid, { content: c, isError: !!block.is_error });
      }
    }
    const cwdForReplay = this.resolveCwd();
    const flushPendingProse = () => {
      if (!pendingAssistantOpen)
        return;
      const text = pendingAssistantText;
      pendingAssistantText = "";
      pendingAssistantOpen = false;
      if (!text.trim())
        return;
      const buf = this.startAssistantBuffer(pendingAssistantWhen);
      buf.text = text;
      this.flushAssistantRender(buf);
      closeReplayGroup();
    };
    const closeReplayGroup = () => {
      if (!replayGroup)
        return;
      replayGroup.el.removeClass("cfo-tool-group-running");
      this.updateToolGroupHeader(replayGroup);
      replayGroup = null;
    };
    const appendReplayToolRow = (name, input, toolUseId) => {
      if (!replayGroup) {
        const turn = this.ensureClaudeTurn(pendingAssistantWhen);
        const el = turn.createDiv({ cls: "cfo-tool-group" });
        const headerEl = el.createDiv({ cls: "cfo-tool-group-header" });
        const chevron = headerEl.createSpan({ cls: "cfo-tool-group-chevron" });
        (0, import_obsidian3.setIcon)(chevron, "chevron-down");
        const statusEl = headerEl.createSpan({ cls: "cfo-tool-group-status", text: "Ran" });
        const bodyEl = el.createDiv({ cls: "cfo-tool-group-body" });
        replayGroup = {
          el,
          headerEl,
          bodyEl,
          statusEl,
          runningByName: /* @__PURE__ */ new Map(),
          seenNames: [],
          loadedSkills: [],
          expanded: false
        };
        const groupRef = replayGroup;
        headerEl.onclick = () => {
          groupRef.expanded = !groupRef.expanded;
          groupRef.el.toggleClass("cfo-tool-group-expanded", groupRef.expanded);
        };
      }
      if (!replayGroup.seenNames.includes(name))
        replayGroup.seenNames.push(name);
      if (name === "Skill" && input && typeof input.skill === "string") {
        replayGroup.loadedSkills.push(input.skill);
      }
      const result = toolUseId ? toolResultsById.get(toolUseId) ?? null : null;
      const out = renderToolRow(name, input, result, { cwd: cwdForReplay, toolUseId });
      const row = replayGroup.bodyEl.createDiv({ cls: "cfo-tool-row" });
      if (result?.isError)
        row.addClass("cfo-tool-row-error");
      this.paintToolRow(
        row,
        out,
        /*withDot=*/
        true
      );
    };
    for (const line of raw.split("\n")) {
      if (!line.trim())
        continue;
      let evt;
      try {
        evt = JSON.parse(line);
      } catch {
        continue;
      }
      const when = typeof evt.timestamp === "string" ? new Date(evt.timestamp) : /* @__PURE__ */ new Date();
      if (evt.type === "user" && evt.message) {
        const content = evt.message.content;
        let userText = "";
        if (typeof content === "string") {
          userText = content;
        } else if (Array.isArray(content)) {
          const hasOnlyToolResults = content.every((b) => b?.type === "tool_result");
          if (hasOnlyToolResults)
            continue;
          userText = content.filter((b) => b?.type === "text" && typeof b.text === "string").map((b) => b.text).join("\n");
        }
        if (!userText)
          continue;
        if (this.isSkillInjection(userText))
          continue;
        flushPendingProse();
        closeReplayGroup();
        this.appendUserBlock(userText, when);
        continue;
      }
      if (evt.type === "assistant" && evt.message?.content) {
        if (!pendingAssistantOpen)
          pendingAssistantWhen = when;
        for (const block of evt.message.content) {
          if (block.type === "text" && typeof block.text === "string") {
            if (!pendingAssistantOpen)
              pendingAssistantOpen = true;
            pendingAssistantText += block.text;
          } else if (block.type === "tool_use") {
            flushPendingProse();
            appendReplayToolRow(block.name, block.input, typeof block.id === "string" ? block.id : null);
          }
        }
        const usage = evt.message.usage;
        if (usage && typeof usage === "object") {
          const turn = this.tokensFromUsage(usage);
          if (turn > lastTokenTotal)
            lastTokenTotal = turn;
        }
        continue;
      }
    }
    flushPendingProse();
    closeReplayGroup();
    this.closeClaudeTurn();
    if (lastTokenTotal > 0) {
      this.sessionTokensUsed = lastTokenTotal;
      this.renderBattery();
    }
  }
  newChat() {
    if (this.turnBusy) {
      new import_obsidian3.Notice("Cannot start a new chat while a run is in progress.");
      return;
    }
    this.endSession();
    this.activeSessionId = null;
    this.plugin.settings.activeSessionId = null;
    this.pendingTitle = null;
    this.plugin.saveSettings();
    this.outputEl.empty();
    this.currentClaudeTurn = null;
    this.currentToolGroup = null;
    this.currentAssistant = null;
    this.sessionTokensUsed = 0;
    this.lastDateKey = null;
    this.renderBattery();
    this.refreshChatTitle();
    this.clearStatus();
    this.renderSplash();
  }
  /** Splash content shown when no chat is active — replaces the
   *  default behaviour of opening with an empty `(empty)` chat that
   *  pollutes the session list. Hidden the moment any real content
   *  appends to outputEl (user message, tool use, or replay). */
  renderSplash() {
    this.clearSplash();
    const splash = this.outputEl.createDiv({ cls: "cfo-splash" });
    splash.createDiv({ cls: "cfo-splash-greeting", text: "Welcome back." });
    splash.createDiv({ cls: "cfo-splash-prompt", text: "What are we writing today?" });
  }
  clearSplash() {
    const existing = this.outputEl.querySelector(".cfo-splash");
    if (existing)
      existing.remove();
  }
  deleteCurrentChat() {
    if (this.turnBusy) {
      new import_obsidian3.Notice("Cannot delete chat while a run is in progress.");
      return;
    }
    this.endSession();
    const id = this.activeSessionId;
    if (!id) {
      new import_obsidian3.Notice("No active chat to delete.");
      return;
    }
    const filePath = this.findSessionFile(id);
    if (filePath) {
      try {
        fs2.unlinkSync(filePath);
      } catch (e) {
        new import_obsidian3.Notice(`Could not delete session file: ${e.message}`);
        return;
      }
    }
    this.newChat();
  }
  async saveChatToVault() {
    if (this.turnBusy) {
      new import_obsidian3.Notice("Cannot save chat while a run is in progress.");
      return;
    }
    const id = this.activeSessionId;
    if (!id) {
      new import_obsidian3.Notice("No active chat to save.");
      return;
    }
    const filePath = this.findSessionFile(id);
    if (!filePath) {
      new import_obsidian3.Notice("Could not locate session file on disk.");
      return;
    }
    const exported = exportSession({
      jsonlPath: filePath,
      cwd: this.resolveCwd(),
      vaultName: this.vaultName()
    });
    if (!exported) {
      new import_obsidian3.Notice("Could not parse session jsonl.");
      return;
    }
    const folder = this.newFileFolder();
    const targetPath = (0, import_obsidian3.normalizePath)(folder ? `${folder}/${exported.filename}` : exported.filename);
    try {
      const existing = this.app.vault.getAbstractFileByPath(targetPath);
      let file;
      if (existing instanceof import_obsidian3.TFile) {
        await this.app.vault.modify(existing, exported.body);
        file = existing;
      } else {
        file = await this.app.vault.create(targetPath, exported.body);
      }
      const leaf = this.app.workspace.getLeaf(false);
      await leaf.openFile(file);
      new import_obsidian3.Notice(`Saved chat to ${targetPath}`);
    } catch (e) {
      new import_obsidian3.Notice(`Save failed: ${e.message}`);
    }
  }
  newFileFolder() {
    const cfg = this.app.vault.getConfig?.bind(this.app.vault);
    if (!cfg)
      return "";
    const loc = cfg("newFileLocation");
    if (loc === "root" || !loc)
      return "";
    const folder = cfg("newFileFolderPath");
    if (typeof folder === "string" && folder.trim())
      return folder.trim();
    return "";
  }
  findSessionFile(id) {
    const candidate = path.join(this.projectsRoot(), this.encodedCwd(), `${id}.jsonl`);
    return fs2.existsSync(candidate) ? candidate : null;
  }
  dateKey(d) {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }
  formatHM(d) {
    return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
  }
  maybeAppendDateDivider(d) {
    const key = this.dateKey(d);
    if (this.lastDateKey === key)
      return;
    this.lastDateKey = key;
    const divider = this.outputEl.createDiv({ cls: "cfo-date-divider" });
    const inner = divider.createSpan({ cls: "cfo-date-divider-text" });
    this.renderMarkdownInto(`[[${key}]]`, inner);
  }
  appendUserBlock(text, when = /* @__PURE__ */ new Date()) {
    this.clearSplash();
    this.closeClaudeTurn();
    this.maybeAppendDateDivider(when);
    const block = this.outputEl.createDiv({ cls: "cfo-message cfo-message-user" });
    const role = block.createDiv({ cls: "cfo-message-role" });
    role.createSpan({ cls: "cfo-message-role-label", text: "You" });
    role.createSpan({ cls: "cfo-message-time", text: this.formatHM(when) });
    const body = block.createDiv({ cls: "cfo-message-body" });
    this.renderMarkdownInto(text, body);
    this.bumpTrailingThinking();
    this.outputEl.scrollTop = this.outputEl.scrollHeight;
  }
  /**
   * Open (or return) the wrapper for the current Claude turn. Commits
   * the CLAUDE header on first call. Every prose block, tool group, and
   * final reply for the turn appends inside this wrapper.
   */
  ensureClaudeTurn(when = /* @__PURE__ */ new Date()) {
    if (this.currentClaudeTurn)
      return this.currentClaudeTurn;
    this.clearSplash();
    this.maybeAppendDateDivider(when);
    const wrapper = this.outputEl.createDiv({ cls: "cfo-turn-claude" });
    const role = wrapper.createDiv({ cls: "cfo-turn-claude-role" });
    role.createSpan({ cls: "cfo-message-role-label", text: "Claude" });
    this.currentClaudeTurn = wrapper;
    this.bumpTrailingThinking();
    this.outputEl.scrollTop = this.outputEl.scrollHeight;
    return wrapper;
  }
  /**
   * End the current Claude turn. Settles any open tool group, clears
   * the assistant buffer pointer, and drops the wrapper reference so
   * the next agent event opens a fresh turn.
   */
  closeClaudeTurn() {
    if (this.currentToolGroup)
      this.closeToolGroup();
    this.currentAssistant = null;
    this.currentClaudeTurn = null;
  }
  startAssistantBuffer(when = /* @__PURE__ */ new Date()) {
    const turn = this.ensureClaudeTurn(when);
    const containerEl = turn.createDiv({ cls: "cfo-message cfo-message-assistant" });
    const bodyEl = containerEl.createDiv({ cls: "cfo-message-body" });
    this.bumpTrailingThinking();
    this.outputEl.scrollTop = this.outputEl.scrollHeight;
    return {
      containerEl,
      bodyEl,
      text: "",
      revealedLen: 0,
      revealRaf: null,
      lastFrameAt: null
    };
  }
  /**
   * Paced reveal. Decouples the visual stream from network arrival:
   * appends to `buf.text` happen as chunks arrive, but the rendered DOM
   * only shows characters up to `buf.revealedLen`, advanced by a steady
   * rate per animation frame. Long dumps still arrive smoothly; short
   * pauses still feel like the agent is typing.
   */
  scheduleAssistantRender(buf) {
    if (buf.revealRaf != null)
      return;
    const tick = (now) => {
      buf.revealRaf = null;
      const last = buf.lastFrameAt ?? now;
      const dt = Math.max(0, now - last);
      buf.lastFrameAt = now;
      const remaining = buf.text.length - buf.revealedLen;
      if (remaining <= 0) {
        buf.lastFrameAt = null;
        return;
      }
      const rate = remaining > REVEAL_BURST_THRESHOLD ? REVEAL_BASE_CPS * REVEAL_BURST_MULTIPLIER : REVEAL_BASE_CPS;
      const advance = Math.max(1, Math.floor(rate * dt / 1e3));
      buf.revealedLen = Math.min(buf.text.length, buf.revealedLen + advance);
      this.renderMarkdownInto(buf.text.slice(0, buf.revealedLen), buf.bodyEl);
      this.bumpTrailingThinking();
      this.outputEl.scrollTop = this.outputEl.scrollHeight;
      if (buf.revealedLen < buf.text.length) {
        buf.revealRaf = window.requestAnimationFrame(tick);
      } else {
        buf.lastFrameAt = null;
      }
    };
    buf.revealRaf = window.requestAnimationFrame(tick);
  }
  flushAssistantRender(buf) {
    if (buf.revealRaf != null) {
      window.cancelAnimationFrame(buf.revealRaf);
      buf.revealRaf = null;
    }
    buf.revealedLen = buf.text.length;
    buf.lastFrameAt = null;
    this.renderMarkdownInto(buf.text, buf.bodyEl);
    this.outputEl.scrollTop = this.outputEl.scrollHeight;
  }
  renderMarkdownInto(markdown, el) {
    el.empty();
    import_obsidian3.MarkdownRenderer.render(this.app, markdown, el, this.resolveCwd(), this.renderComponent);
    this.bindInternalLinks(el);
  }
  bindInternalLinks(el) {
    const links = el.querySelectorAll("a.internal-link");
    links.forEach((node) => {
      const a = node;
      const linkText = a.getAttr("href") || a.getAttr("data-href") || a.textContent || "";
      const linkpath = linkText.split("#")[0].split("|")[0];
      const dest = linkpath ? this.app.metadataCache.getFirstLinkpathDest(linkpath, "") : null;
      a.toggleClass("cfo-link-unresolved", !dest);
      if (a.dataset.cfoBound === "1")
        return;
      a.dataset.cfoBound = "1";
      a.addEventListener("click", (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        const newLeaf = evt.metaKey || evt.ctrlKey;
        this.app.workspace.openLinkText(linkText, this.resolveCwd(), newLeaf);
      });
      a.addEventListener("mouseover", (evt) => {
        this.app.workspace.trigger("hover-link", {
          event: evt,
          source: "claude-for-obsidian",
          hoverParent: this.renderComponent,
          targetEl: a,
          linktext: linkText,
          sourcePath: ""
        });
      });
    });
    const tags = el.querySelectorAll("a.tag");
    tags.forEach((node) => {
      const a = node;
      if (a.dataset.cfoBound === "1")
        return;
      a.dataset.cfoBound = "1";
      const raw = a.getAttr("href") || a.textContent || "";
      const tagName = raw.replace(/^#/, "");
      a.addEventListener("click", (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        this.openTagSearch(tagName);
      });
    });
  }
  openTagSearch(tagName) {
    const search = this.app.internalPlugins?.getPluginById?.("global-search");
    const instance = search?.instance;
    if (instance?.openGlobalSearch) {
      instance.openGlobalSearch(`tag:#${tagName}`);
      return;
    }
    new import_obsidian3.Notice(`Tag: #${tagName}`);
  }
  ensureToolGroup() {
    if (this.currentToolGroup)
      return this.currentToolGroup;
    const turn = this.ensureClaudeTurn();
    const el = turn.createDiv({ cls: "cfo-tool-group cfo-tool-group-running" });
    const headerEl = el.createDiv({ cls: "cfo-tool-group-header" });
    const chevron = headerEl.createSpan({ cls: "cfo-tool-group-chevron" });
    (0, import_obsidian3.setIcon)(chevron, "chevron-down");
    const statusEl = headerEl.createSpan({ cls: "cfo-tool-group-status", text: "Running\u2026" });
    const bodyEl = el.createDiv({ cls: "cfo-tool-group-body" });
    const group = {
      el,
      headerEl,
      bodyEl,
      statusEl,
      runningByName: /* @__PURE__ */ new Map(),
      seenNames: [],
      loadedSkills: [],
      expanded: false
    };
    headerEl.onclick = () => {
      group.expanded = !group.expanded;
      group.el.toggleClass("cfo-tool-group-expanded", group.expanded);
    };
    this.currentToolGroup = group;
    this.bumpTrailingThinking();
    return group;
  }
  updateToolGroupHeader(group) {
    const runningTotal = Array.from(group.runningByName.values()).reduce((a, b) => a + b, 0);
    if (runningTotal > 0) {
      const activeName = [...group.runningByName.entries()].find(([, n]) => n > 0)?.[0];
      const verb = activeName ? this.toolVerbForName(activeName) : "Running";
      group.statusEl.setText(`${verb}\u2026`);
      return;
    }
    const baseLabel = group.seenNames.length === 1 ? `Ran ${group.seenNames[0]}` : `Ran ${group.seenNames.length} tools`;
    const skillTag = this.skillTagFor(group);
    group.statusEl.setText(skillTag ? `${baseLabel} ${skillTag}` : baseLabel);
  }
  skillTagFor(group) {
    const skills = group.loadedSkills.filter((s, i, arr) => arr.indexOf(s) === i);
    if (skills.length === 0)
      return "";
    if (skills.length === 1)
      return `(loaded ${skills[0]} skill)`;
    return `(loaded ${skills.join(", ")} skills)`;
  }
  closeToolGroup() {
    if (!this.currentToolGroup)
      return;
    this.currentToolGroup.el.removeClass("cfo-tool-group-running");
    this.updateToolGroupHeader(this.currentToolGroup);
    this.currentToolGroup = null;
  }
  appendToolUse(id, name, input) {
    const out = renderToolRow(name, input, null, { cwd: this.resolveCwd(), toolUseId: id });
    if (id === null) {
      const flat = this.outputEl.createDiv({ cls: "cfo-tool-row cfo-tool-row-replay" });
      this.paintToolRow(
        flat,
        out,
        /*withDot=*/
        false
      );
      this.outputEl.scrollTop = this.outputEl.scrollHeight;
      return;
    }
    const group = this.ensureToolGroup();
    if (!group.seenNames.includes(name))
      group.seenNames.push(name);
    group.runningByName.set(name, (group.runningByName.get(name) ?? 0) + 1);
    if (name === "Skill" && input && typeof input.skill === "string") {
      group.loadedSkills.push(input.skill);
    }
    const row = group.bodyEl.createDiv({ cls: "cfo-tool-row cfo-tool-row-running" });
    this.paintToolRow(
      row,
      out,
      /*withDot=*/
      true
    );
    this.pendingTools.set(id, { el: row, startedAt: Date.now(), group, name, input });
    this.updateToolGroupHeader(group);
    this.bumpTrailingThinking();
    this.outputEl.scrollTop = this.outputEl.scrollHeight;
  }
  /**
   * Paint a RenderOutput into a tool-row element. Re-entrant: callers
   * pass an empty row first time (live tool_use, replay walk) and the
   * same row a second time when the result settles (live only) — the
   * function clears and rebuilds the row body.
   */
  paintToolRow(row, out, withDot) {
    row.empty();
    if (withDot)
      row.createSpan({ cls: "cfo-tool-row-dot" });
    if (out.flat) {
      row.createSpan({ cls: "cfo-tool-row-name", text: out.verb });
      row.appendText(" ");
      row.createSpan({ cls: "cfo-tool-row-args", text: out.flat });
      return;
    }
    const verbEl = row.createSpan({ cls: "cfo-tool-row-name" });
    verbEl.setText(out.verb);
    if (out.verb && out.target)
      row.appendText(" ");
    const targetEl = row.createSpan({ cls: "cfo-tool-row-target" });
    targetEl.setText(out.target);
    const hasAdd = typeof out.addCount === "number" && out.addCount > 0;
    const hasDel = typeof out.delCount === "number" && out.delCount > 0;
    if (hasAdd || hasDel) {
      row.appendText(" ");
      if (hasAdd) {
        row.createSpan({ cls: "cfo-tool-row-add-count", text: `+${out.addCount}` });
      }
      if (hasAdd && hasDel)
        row.appendText(" ");
      if (hasDel) {
        row.createSpan({ cls: "cfo-tool-row-del-count", text: `-${out.delCount}` });
      }
    } else if (out.suffix) {
      row.createSpan({ cls: "cfo-tool-row-suffix", text: out.suffix });
    }
    if (out.expand) {
      const chevron = row.createSpan({ cls: "cfo-tool-row-chevron" });
      (0, import_obsidian3.setIcon)(chevron, "chevron-down");
      const body = row.createDiv({ cls: "cfo-tool-row-expand" });
      let painted = false;
      let expanded = false;
      const ensurePainted = () => {
        if (!painted) {
          out.expand(body);
          painted = true;
        }
      };
      const toggle = (e) => {
        e.stopPropagation();
        expanded = !expanded;
        if (expanded)
          ensurePainted();
        row.toggleClass("cfo-tool-row-expanded", expanded);
      };
      chevron.onclick = toggle;
      row.onclick = (e) => {
        if (e.target?.closest(".cfo-tool-row-expand"))
          return;
        toggle(e);
      };
      if (out.expandDefault) {
        expanded = true;
        ensurePainted();
        row.addClass("cfo-tool-row-expanded");
      }
    }
  }
  /**
   * Detect skill-injection user messages. Claude Code injects a skill
   * body into the model context as a `user` text message that follows a
   * `Skill` tool call. The body always starts with "Base directory for
   * this skill:". Suppress these from the visible chat — they're
   * mechanism, not conversation.
   */
  isSkillInjection(text) {
    return text.trimStart().startsWith("Base directory for this skill:");
  }
  toolVerbForName(name) {
    const verbs = {
      Read: "Reading",
      Write: "Writing",
      Edit: "Editing",
      Bash: "Running",
      Glob: "Searching",
      Grep: "Searching",
      Task: "Delegating",
      WebFetch: "Fetching",
      WebSearch: "Searching",
      ToolSearch: "Loading",
      TodoWrite: "Planning",
      NotebookEdit: "Editing"
    };
    return verbs[name] ?? name;
  }
  settleToolResult(id, isError, content) {
    if (!id)
      return;
    const entry = this.pendingTools.get(id);
    if (!entry)
      return;
    this.pendingTools.delete(id);
    const elapsed = Date.now() - entry.startedAt;
    const wait = Math.max(0, _ClaudeForObsidianView.TOOL_MIN_VISIBLE_MS - elapsed);
    const settle = () => {
      entry.el.removeClass("cfo-tool-row-running");
      if (isError)
        entry.el.addClass("cfo-tool-row-error");
      const result = { content, isError };
      const out = renderToolRow(entry.name, entry.input, result, {
        cwd: this.resolveCwd(),
        toolUseId: id
      });
      this.paintToolRow(
        entry.el,
        out,
        /*withDot=*/
        true
      );
      const remaining = (entry.group.runningByName.get(entry.name) ?? 1) - 1;
      if (remaining <= 0)
        entry.group.runningByName.delete(entry.name);
      else
        entry.group.runningByName.set(entry.name, remaining);
      this.updateToolGroupHeader(entry.group);
    };
    if (wait === 0)
      settle();
    else
      window.setTimeout(settle, wait);
  }
  settleAllPendingTools() {
    for (const entry of this.pendingTools.values()) {
      entry.el.removeClass("cfo-tool-row-running");
    }
    this.pendingTools.clear();
    if (this.currentToolGroup) {
      this.currentToolGroup.runningByName.clear();
      this.updateToolGroupHeader(this.currentToolGroup);
      this.closeToolGroup();
    }
  }
  // ---------- permission dialog ----------
  enqueuePermissionRequest(req) {
    if (!this.needsPermissionDialog(req.toolName, req.input)) {
      if (this.currentSession) {
        this.currentSession.respondPermission(req.requestId, {
          behavior: "allow",
          updatedInput: req.input ?? {}
        });
      }
      return;
    }
    this.permissionQueue.push(req);
    if (!this.activePermissionRequest) {
      this.showNextPermissionRequest();
    }
  }
  /** Decide whether a tool use warrants a dialog. Mirrors the rough
   *  shape of the CLI's permission system but driven by the user's
   *  chosen mode in the bottom-nav. Reads/searches inside the vault
   *  are silent; writes, edits, and Bash always ask in default mode
   *  and stay silent in acceptEdits / bypassPermissions. */
  needsPermissionDialog(toolName, input) {
    const mode = this.plugin.settings.permissionMode;
    if (mode === "bypassPermissions")
      return false;
    if (toolName === "Bash") {
      const cmd = typeof input?.command === "string" ? input.command : "";
      if (hasBashSafetyOverride(cmd))
        return true;
    }
    if (matchesAllowRule(toolName, input, this.allowRules))
      return false;
    const isWrite = toolName === "Edit" || toolName === "Write" || toolName === "NotebookEdit";
    if (isWrite)
      return mode !== "acceptEdits";
    if (toolName === "Bash") {
      const cmd = typeof input?.command === "string" ? input.command : "";
      if (isSafeBashCommand(cmd))
        return false;
      return true;
    }
    if (toolName === "WebFetch" || toolName === "WebSearch")
      return mode === "default";
    if (toolName === "Read" || toolName === "Glob" || toolName === "Grep") {
      const p = typeof input?.file_path === "string" ? input.file_path : typeof input?.path === "string" ? input.path : "";
      if (!p)
        return false;
      const cwd = this.resolveCwd();
      if (!cwd)
        return false;
      return !p.startsWith(cwd);
    }
    return false;
  }
  showNextPermissionRequest() {
    const next = this.permissionQueue.shift();
    if (!next) {
      this.activePermissionRequest = null;
      this.hidePermissionDialog();
      return;
    }
    this.activePermissionRequest = next;
    this.paintPermissionDialog(next);
  }
  paintPermissionDialog(req) {
    const host = this.permissionDialogEl;
    if (!host)
      return;
    host.empty();
    host.removeClass("cfo-permission-dialog-hidden");
    const header = host.createDiv({ cls: "cfo-permission-header" });
    header.createSpan({ cls: "cfo-permission-dot" });
    header.createSpan({
      cls: "cfo-permission-title",
      text: this.humanPermissionTitle(req.toolName, req.input)
    });
    header.createSpan({ cls: "cfo-permission-badge", text: "session" });
    if (req.decisionReason || req.blockedPath) {
      const reason = host.createDiv({ cls: "cfo-permission-reason" });
      if (req.decisionReason) {
        reason.createDiv({ cls: "cfo-permission-reason-text", text: req.decisionReason });
      }
      if (req.blockedPath) {
        reason.createDiv({ cls: "cfo-permission-reason-path", text: req.blockedPath });
      }
    }
    const body = host.createDiv({ cls: "cfo-permission-body" });
    this.paintPermissionBody(req, body);
    const footer = host.createDiv({ cls: "cfo-permission-footer" });
    const denyBtn = footer.createEl("button", { cls: "cfo-permission-btn cfo-permission-btn-deny" });
    denyBtn.createSpan({ text: "Deny" });
    denyBtn.createSpan({ cls: "cfo-permission-chord", text: "esc" });
    denyBtn.onclick = () => this.settlePermissionRequest({ behavior: "deny", message: "User denied" });
    const spacer = footer.createDiv({ cls: "cfo-permission-spacer" });
    const safetyBlocksRule = req.toolName === "Bash" && hasBashSafetyOverride(typeof req.input?.command === "string" ? req.input.command : "");
    if (!safetyBlocksRule) {
      const alwaysBtn = footer.createEl("button", {
        cls: "cfo-permission-btn cfo-permission-btn-always"
      });
      alwaysBtn.createSpan({ text: "Allow always" });
      alwaysBtn.createSpan({ cls: "cfo-permission-chord", text: "\u25BE" });
      alwaysBtn.onclick = (e) => {
        e.stopPropagation();
        this.toggleAllowAlwaysPopup(alwaysBtn, req);
      };
    }
    const allowBtn = footer.createEl("button", { cls: "cfo-permission-btn cfo-permission-btn-allow" });
    allowBtn.createSpan({ text: "Allow once" });
    allowBtn.createSpan({ cls: "cfo-permission-chord", text: "\u2318\u23CE" });
    allowBtn.onclick = () => this.settlePermissionRequest({ behavior: "allow", updatedInput: req.input ?? {} });
    this.bindPermissionKeys();
    this.clearStatus();
    this.statusEl.setText("Waiting for permission decision\u2026");
  }
  paintPermissionBody(req, host) {
    const { toolName, input } = req;
    if (toolName === "Edit") {
      const filePath = typeof input?.file_path === "string" ? input.file_path : "";
      host.createDiv({ cls: "cfo-permission-path", text: filePath });
      const ops = lineDiff(
        typeof input?.old_string === "string" ? input.old_string : "",
        typeof input?.new_string === "string" ? input.new_string : ""
      );
      renderDiff(host, ops);
      return;
    }
    if (toolName === "Write") {
      const filePath = typeof input?.file_path === "string" ? input.file_path : "";
      const content = typeof input?.content === "string" ? input.content : "";
      host.createDiv({ cls: "cfo-permission-path", text: filePath });
      renderDiff(host, lineDiff("", content));
      return;
    }
    if (toolName === "NotebookEdit") {
      const filePath = typeof input?.notebook_path === "string" ? input.notebook_path : "";
      host.createDiv({ cls: "cfo-permission-path", text: filePath });
      return;
    }
    if (toolName === "Read") {
      const filePath = typeof input?.file_path === "string" ? input.file_path : "";
      host.createDiv({ cls: "cfo-permission-path", text: filePath });
      return;
    }
    if (toolName === "Bash") {
      const cmd = typeof input?.command === "string" ? input.command : "";
      const desc = typeof input?.description === "string" ? input.description : "";
      if (desc)
        host.createDiv({ cls: "cfo-permission-desc", text: desc });
      const codeEl = host.createEl("pre", { cls: "cfo-permission-code" });
      codeEl.setText(cmd);
      const warnings = this.bashShapeWarnings(cmd);
      if (warnings.length > 0) {
        const warnEl = host.createDiv({ cls: "cfo-permission-warnings" });
        for (const w of warnings) {
          warnEl.createDiv({ cls: "cfo-permission-warning", text: `\u26A0 ${w}` });
        }
      }
      return;
    }
    if (toolName === "Glob" || toolName === "Grep") {
      const pattern = typeof input?.pattern === "string" ? input.pattern : "";
      const p = typeof input?.path === "string" ? input.path : "";
      host.createDiv({ cls: "cfo-permission-desc", text: pattern });
      if (p)
        host.createDiv({ cls: "cfo-permission-path", text: p });
      return;
    }
    if (toolName === "WebFetch") {
      const url = typeof input?.url === "string" ? input.url : "";
      host.createDiv({ cls: "cfo-permission-path", text: url });
      return;
    }
    if (toolName === "WebSearch") {
      const query = typeof input?.query === "string" ? input.query : "";
      host.createDiv({ cls: "cfo-permission-desc", text: query });
      return;
    }
    const pre = host.createEl("pre", { cls: "cfo-permission-code" });
    try {
      pre.setText(JSON.stringify(input ?? {}, null, 2));
    } catch {
      pre.setText(String(input ?? ""));
    }
  }
  humanPermissionTitle(toolName, input) {
    const basename2 = (p) => {
      if (typeof p !== "string" || !p)
        return "";
      const slash = p.lastIndexOf("/");
      return slash === -1 ? p : p.slice(slash + 1);
    };
    if (toolName === "Edit" || toolName === "Write" || toolName === "NotebookEdit") {
      const name = basename2(input?.file_path ?? input?.notebook_path ?? "");
      return name ? `Allow Claude to edit ${name}?` : "Allow Claude to edit a file?";
    }
    if (toolName === "Read") {
      const name = basename2(input?.file_path ?? "");
      return name ? `Allow Claude to read ${name}?` : "Allow Claude to read a file?";
    }
    if (toolName === "Bash")
      return "Allow Claude to run a command?";
    if (toolName === "Glob" || toolName === "Grep")
      return "Allow Claude to search?";
    if (toolName === "WebFetch")
      return "Allow Claude to fetch from the web?";
    if (toolName === "WebSearch")
      return "Allow Claude to search the web?";
    return `Allow Claude to use ${toolName}?`;
  }
  bashShapeWarnings(cmd) {
    const warnings = [];
    if (!cmd)
      return warnings;
    if (/\\\s/.test(cmd))
      warnings.push("Contains backslash-escaped whitespace");
    const singles = (cmd.match(/(?<!\\)'/g) ?? []).length;
    const doubles = (cmd.match(/(?<!\\)"/g) ?? []).length;
    if (singles % 2 !== 0)
      warnings.push("Unbalanced single quotes");
    if (doubles % 2 !== 0)
      warnings.push("Unbalanced double quotes");
    if (/\brm\s+-rf?\s+\/\b/.test(cmd) || /\brm\s+-rf?\s+~\/?/.test(cmd))
      warnings.push("Recursive rm targets a root or home path");
    return warnings;
  }
  settlePermissionRequest(decision) {
    const active = this.activePermissionRequest;
    if (!active)
      return;
    this.activePermissionRequest = null;
    if (this.currentSession) {
      this.currentSession.respondPermission(active.requestId, decision);
    }
    this.unbindPermissionKeys();
    this.dismissAllowAlwaysPopup();
    this.clearStatus();
    this.showNextPermissionRequest();
  }
  /** Open / close the "Allow always for ..." scope-picker popup
   *  anchored on the dialog's Allow-always button. Click a row to
   *  add the rule to the session and allow the call. */
  toggleAllowAlwaysPopup(triggerEl, req) {
    if (this.containerEl.ownerDocument.querySelector(".cfo-allow-always-popup")) {
      this.dismissAllowAlwaysPopup();
      return;
    }
    const doc = this.containerEl.ownerDocument;
    const win = doc.defaultView;
    const popup = doc.body.createDiv({ cls: "cfo-allow-always-popup" });
    const rect = triggerEl.getBoundingClientRect();
    popup.style.bottom = `${win.innerHeight - rect.top + 6}px`;
    popup.style.left = `${Math.max(8, rect.left)}px`;
    triggerEl.addClass("cfo-permission-btn-active");
    popup.createDiv({
      cls: "cfo-allow-always-popup-label",
      text: "Allow always for\u2026"
    });
    const cwd = this.resolveCwd();
    const suggestions = generateRuleSuggestions(req.toolName, req.input, cwd);
    for (const s of suggestions) {
      const row = popup.createDiv({ cls: "cfo-allow-always-row" });
      const ruleCol = row.createDiv({ cls: "cfo-allow-always-rule" });
      ruleCol.setText(s.rule.display);
      const descCol = row.createDiv({ cls: "cfo-allow-always-desc" });
      descCol.setText(scopeDescription(s.scope, req.toolName));
      if (s.scope === "all") {
        row.createSpan({ cls: "cfo-allow-always-chord", text: "\u2318\u21E7\u23CE" });
      }
      row.addEventListener("mousedown", (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.acceptAllowAlways(s.rule);
      });
    }
    const margin = 8;
    const maxLeft = win.innerWidth - popup.offsetWidth - margin;
    if (popup.offsetLeft > maxLeft) {
      popup.style.left = `${Math.max(margin, maxLeft)}px`;
    }
    const dismiss = (e) => {
      if (popup.contains(e.target))
        return;
      if (triggerEl.contains(e.target))
        return;
      this.dismissAllowAlwaysPopup();
    };
    win.addEventListener("mousedown", dismiss);
    popup.cfoDismiss = dismiss;
  }
  dismissAllowAlwaysPopup() {
    const doc = this.containerEl.ownerDocument;
    const popup = doc.querySelector(".cfo-allow-always-popup");
    if (popup) {
      const dismiss = popup.cfoDismiss;
      if (dismiss)
        doc.defaultView?.removeEventListener("mousedown", dismiss);
      popup.remove();
    }
    doc.querySelectorAll(".cfo-permission-btn-always").forEach(
      (b) => b.classList.remove("cfo-permission-btn-active")
    );
  }
  /** Add a session-scoped allow-rule and settle the active request
   *  as an Allow. Called from the popup row click and the ⌘⇧⏎ chord. */
  acceptAllowAlways(rule) {
    if (!this.allowRules.some((r) => r.display === rule.display)) {
      this.allowRules.push(rule);
    }
    const active = this.activePermissionRequest;
    const input = active?.input ?? {};
    this.settlePermissionRequest({ behavior: "allow", updatedInput: input });
  }
  hidePermissionDialog() {
    if (!this.permissionDialogEl)
      return;
    this.permissionDialogEl.empty();
    this.permissionDialogEl.addClass("cfo-permission-dialog-hidden");
    this.unbindPermissionKeys();
  }
  bindPermissionKeys() {
    this.unbindPermissionKeys();
    const handler = (e) => {
      if (!this.activePermissionRequest)
        return;
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        this.settlePermissionRequest({ behavior: "deny", message: "User denied" });
        return;
      }
      if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        e.stopPropagation();
        if (e.shiftKey) {
          const active = this.activePermissionRequest;
          const rule = {
            toolName: active.toolName,
            pattern: null,
            display: active.toolName
          };
          this.acceptAllowAlways(rule);
        } else {
          const input = this.activePermissionRequest.input ?? {};
          this.settlePermissionRequest({ behavior: "allow", updatedInput: input });
        }
        return;
      }
    };
    this.permissionKeyHandler = handler;
    document.addEventListener("keydown", handler, true);
  }
  unbindPermissionKeys() {
    if (this.permissionKeyHandler) {
      document.removeEventListener("keydown", this.permissionKeyHandler, true);
      this.permissionKeyHandler = null;
    }
  }
  send() {
    const prompt = this.inputEl.value.trim();
    if (!prompt)
      return;
    if (this.turnBusy) {
      new import_obsidian3.Notice("A run is already in progress.");
      return;
    }
    const cwd = this.resolveCwd();
    if (!cwd) {
      new import_obsidian3.Notice("Claude for Obsidian: could not resolve vault path.");
      this.statusEl.setText("Error: no vault path.");
      return;
    }
    this.appendUserBlock(prompt);
    if (!this.activeSessionId) {
      this.pendingTitle = prompt;
      this.refreshChatTitle();
    }
    this.inputEl.value = "";
    this.autosizeInput();
    this.currentAssistant = null;
    this.setBusy(true);
    this.setThinking(true);
    this.turnBusy = true;
    if (!this.currentSession) {
      let resumeId = this.activeSessionId;
      if (resumeId && !this.findSessionFile(resumeId)) {
        new import_obsidian3.Notice("Previous session not found; starting fresh.");
        this.activeSessionId = null;
        this.plugin.settings.activeSessionId = null;
        this.plugin.saveSettings();
        resumeId = null;
      }
      this.currentSession = new ClaudeSession({
        cwd,
        settings: this.plugin.settings,
        resumeSessionId: resumeId,
        onEvent: (e) => this.handleEvent(e)
      });
    }
    this.currentSession.sendMessage(this.expandSlashCommand(prompt));
  }
  cancel() {
    if (this.currentSession && this.turnBusy) {
      this.currentSession.cancel();
      this.statusEl.setText("Cancelling\u2026");
    }
  }
  /** End the long-lived subprocess for this chat. Used on chat switch,
   *  new chat, delete-active-chat, panel close. */
  endSession() {
    if (this.currentSession) {
      this.currentSession.end();
      this.currentSession = null;
    }
    this.turnBusy = false;
    this.allowRules = [];
  }
  setBusy(busy) {
    this.sendStopBtn.empty();
    (0, import_obsidian3.setIcon)(this.sendStopBtn, busy ? "square" : "corner-down-left");
    this.sendStopBtn.title = busy ? "Stop (Esc)" : "Send (Enter)";
    this.sendStopBtn.toggleClass("cfo-send-inline-busy", busy);
    if (!busy)
      this.setThinking(false);
  }
  clearStatus() {
    if (!this.statusEl)
      return;
    this.statusEl.empty();
    this.statusEl.removeClass("cfo-status-thinking");
  }
  /**
   * Show or hide the trailing thinking indicator. The indicator lives
   * in the chat stream as the last child of outputEl, trailing whatever
   * the agent emitted most recently (assistant text buffer, tool group,
   * tool row). On every new emission, callers run `bumpTrailingThinking`
   * to push it back to the bottom.
   */
  setThinking(thinking) {
    if (!thinking) {
      this.stopTrailingThinking();
      return;
    }
    this.startTrailingThinking();
  }
  startTrailingThinking() {
    if (this.trailingThinkingTimer != null)
      return;
    if (!this.trailingThinkingEl) {
      this.trailingThinkingEl = this.outputEl.createDiv({ cls: "cfo-trailing-thinking" });
    } else {
      this.bumpTrailingThinking();
    }
    this.renderTrailingThinkingFrame();
    this.trailingThinkingTimer = window.setInterval(
      () => this.renderTrailingThinkingFrame(),
      THINKING_ROTATE_MS
    );
  }
  stopTrailingThinking() {
    if (this.trailingThinkingTimer != null) {
      window.clearInterval(this.trailingThinkingTimer);
      this.trailingThinkingTimer = null;
    }
    if (this.trailingThinkingEl) {
      this.trailingThinkingEl.remove();
      this.trailingThinkingEl = null;
    }
  }
  renderTrailingThinkingFrame() {
    if (!this.trailingThinkingEl)
      return;
    const verb = THINKING_VERBS[Math.floor(Math.random() * THINKING_VERBS.length)];
    this.trailingThinkingEl.empty();
    const dots = this.trailingThinkingEl.createSpan({ cls: "cfo-thinking-dots" });
    dots.createSpan({ cls: "cfo-thinking-dot" });
    dots.createSpan({ cls: "cfo-thinking-dot" });
    dots.createSpan({ cls: "cfo-thinking-dot" });
    this.trailingThinkingEl.createSpan({ cls: "cfo-thinking-label", text: verb });
  }
  /**
   * Re-attach the trailing thinking indicator as the last child of
   * outputEl so it always sits below the most recently emitted block.
   */
  bumpTrailingThinking() {
    if (!this.trailingThinkingEl)
      return;
    this.outputEl.appendChild(this.trailingThinkingEl);
    this.outputEl.scrollTop = this.outputEl.scrollHeight;
  }
  tokensFromUsage(usage) {
    if (!usage || typeof usage !== "object")
      return 0;
    const input = Number(usage.input_tokens) || 0;
    const cacheCreate = Number(usage.cache_creation_input_tokens) || 0;
    const cacheRead = Number(usage.cache_read_input_tokens) || 0;
    return input + cacheCreate + cacheRead;
  }
  renderBattery() {
    if (!this.batteryEl)
      return;
    const window2 = contextWindowForModel(this.plugin.settings.model);
    const used = this.sessionTokensUsed;
    const remaining = Math.max(0, window2 - used);
    const remainingPct = Math.max(0, Math.min(100, Math.round(remaining / window2 * 100)));
    const size = 16;
    const stroke = 2.5;
    const r = (size - stroke) / 2;
    const cx = size / 2;
    const cy = size / 2;
    const circumference = 2 * Math.PI * r;
    const dash = remainingPct / 100 * circumference;
    const gap = circumference - dash;
    let tone = "full";
    if (remainingPct <= 10)
      tone = "urgent";
    else if (remainingPct <= 30)
      tone = "warning";
    else if (remainingPct <= 50)
      tone = "low";
    this.batteryEl.empty();
    this.batteryEl.removeClass("cfo-battery-low");
    this.batteryEl.removeClass("cfo-battery-warning");
    this.batteryEl.removeClass("cfo-battery-urgent");
    if (tone === "low")
      this.batteryEl.addClass("cfo-battery-low");
    else if (tone === "warning")
      this.batteryEl.addClass("cfo-battery-warning");
    else if (tone === "urgent")
      this.batteryEl.addClass("cfo-battery-urgent");
    this.batteryEl.title = `${remainingPct}% context remaining. Click for details.`;
    const ns = "http://www.w3.org/2000/svg";
    const svg = this.batteryEl.createSvg("svg", {
      attr: {
        width: String(size),
        height: String(size),
        viewBox: `0 0 ${size} ${size}`
      }
    });
    svg.createSvg("circle", {
      attr: {
        cx: String(cx),
        cy: String(cy),
        r: String(r),
        fill: "none",
        stroke: "var(--background-modifier-border)",
        "stroke-width": String(stroke)
      }
    });
    const ring = svg.createSvg("circle", {
      attr: {
        cx: String(cx),
        cy: String(cy),
        r: String(r),
        fill: "none",
        "stroke-width": String(stroke),
        "stroke-linecap": "round",
        "stroke-dasharray": `${dash} ${gap}`,
        transform: `rotate(-90 ${cx} ${cy})`
      }
    });
    ring.addClass("cfo-battery-ring");
  }
  /**
   * Render the edits-picker label from the current `permissionMode`,
   * pulling the human label from `MODE_OPTIONS`.
   */
  refreshEditsBtn() {
    if (!this.editsBtn)
      return;
    this.editsBtn.empty();
    const mode = this.plugin.settings.permissionMode;
    const opt = MODE_OPTIONS.find((m) => m.id === mode);
    const label = opt?.label ?? mode;
    this.editsBtn.toggleClass("cfo-edits-btn-bypass", mode === "bypassPermissions");
    this.editsBtn.createSpan({ cls: "cfo-edits-btn-label", text: label });
    const chevron = this.editsBtn.createSpan({ cls: "cfo-edits-btn-chevron" });
    (0, import_obsidian3.setIcon)(chevron, "chevron-down");
    this.editsBtn.title = `Permission mode: ${label}. Click to change.`;
  }
  toggleModePopup() {
    const existing = this.containerEl.ownerDocument.querySelector(".cfo-mode-popup");
    if (existing) {
      this.editsBtn.removeClass("cfo-btn-active");
      existing.remove();
      return;
    }
    this.openModePopup();
  }
  openModePopup() {
    const doc = this.containerEl.ownerDocument;
    const win = doc.defaultView;
    doc.querySelectorAll(".cfo-mode-popup").forEach((el) => el.remove());
    const popup = doc.body.createDiv({ cls: "cfo-mode-popup" });
    const rect = this.editsBtn.getBoundingClientRect();
    popup.style.bottom = `${win.innerHeight - rect.top + 6}px`;
    popup.style.left = `${Math.max(8, rect.left)}px`;
    popup.createDiv({ cls: "cfo-mode-popup-section-label", text: "Mode" });
    for (const m of MODE_OPTIONS) {
      const row = popup.createDiv({ cls: "cfo-mode-popup-row" });
      if (this.plugin.settings.permissionMode === m.id)
        row.addClass("cfo-mode-popup-row-active");
      row.createSpan({ cls: "cfo-mode-popup-row-label", text: m.label });
      if (this.plugin.settings.permissionMode === m.id) {
        const check = row.createSpan({ cls: "cfo-mode-popup-check" });
        (0, import_obsidian3.setIcon)(check, "check");
      }
      row.onclick = async (e) => {
        e.stopPropagation();
        const targetMode = m.id;
        if (targetMode === "bypassPermissions" && !this.plugin.settings.bypassPermissionsConfirmed) {
          this.editsBtn.removeClass("cfo-btn-active");
          popup.remove();
          const ok = await new BypassConfirmModal(this.app, this.resolveCwd()).prompt();
          if (!ok)
            return;
          this.plugin.settings.bypassPermissionsConfirmed = true;
        }
        const prevMode = this.plugin.settings.permissionMode;
        this.plugin.settings.permissionMode = targetMode;
        await this.plugin.saveSettings();
        this.refreshEditsBtn();
        this.editsBtn.removeClass("cfo-btn-active");
        popup.remove();
        if (this.currentSession?.isAlive && targetMode !== prevMode) {
          new import_obsidian3.Notice("Mode change takes effect on the next chat.");
        }
      };
    }
    const margin = 8;
    const maxLeft = win.innerWidth - popup.offsetWidth - margin;
    if (popup.offsetLeft > maxLeft) {
      popup.style.left = `${Math.max(margin, maxLeft)}px`;
    }
    this.editsBtn.addClass("cfo-btn-active");
    const dismiss = (e) => {
      if (popup.contains(e.target))
        return;
      if (this.editsBtn.contains(e.target))
        return;
      this.editsBtn.removeClass("cfo-btn-active");
      popup.remove();
      doc.removeEventListener("mousedown", dismiss, true);
      doc.removeEventListener("keydown", esc, true);
    };
    const esc = (e) => {
      if (e.key === "Escape") {
        this.editsBtn.removeClass("cfo-btn-active");
        popup.remove();
        doc.removeEventListener("mousedown", dismiss, true);
        doc.removeEventListener("keydown", esc, true);
      }
    };
    setTimeout(() => {
      doc.addEventListener("mousedown", dismiss, true);
      doc.addEventListener("keydown", esc, true);
    }, 0);
  }
  refreshModelBtn() {
    if (!this.modelBtn)
      return;
    this.modelBtn.empty();
    const modelId = this.plugin.settings.model || MODEL_OPTIONS[0].id;
    const model = MODEL_OPTIONS.find((m) => m.id === modelId) ?? MODEL_OPTIONS[0];
    const effortId = this.plugin.settings.effort;
    const effort = EFFORT_OPTIONS.find((e) => e.id === effortId) ?? EFFORT_OPTIONS[2];
    const inner = this.modelBtn.createSpan({ cls: "cfo-model-btn-inner" });
    inner.createSpan({ cls: "cfo-model-btn-name", text: model.label });
    if (model.sublabel) {
      inner.createSpan({
        cls: model.legacy ? "cfo-model-btn-sub-legacy" : "cfo-model-btn-sub",
        text: model.sublabel
      });
    }
    inner.createSpan({ cls: "cfo-model-btn-sep", text: "\xB7" });
    inner.createSpan({ cls: "cfo-model-btn-effort", text: effort.label });
  }
  toggleModelMenu() {
    const existing = this.containerEl.ownerDocument.querySelector(".cfo-model-popup");
    if (existing) {
      this.modelBtn.removeClass("cfo-btn-active");
      existing.remove();
      return;
    }
    this.openModelMenu();
  }
  openModelMenu() {
    openModelPopup({
      settings: this.plugin.settings,
      triggerEl: this.modelBtn,
      onModelChange: async (id) => {
        this.plugin.settings.model = id;
        await this.plugin.saveSettings();
        this.refreshModelBtn();
        this.renderBattery();
        if (this.currentSession?.isAlive) {
          new import_obsidian3.Notice("Model change takes effect on the next chat.");
        }
      },
      onEffortChange: async (effort) => {
        this.plugin.settings.effort = effort;
        await this.plugin.saveSettings();
        this.refreshModelBtn();
        if (this.currentSession?.isAlive) {
          new import_obsidian3.Notice("Effort change takes effect on the next chat.");
        }
      }
    });
  }
  togglePlusMenu(triggerEl) {
    const existing = this.containerEl.ownerDocument.querySelector(".cfo-plus-menu");
    if (existing) {
      triggerEl.removeClass("cfo-btn-active");
      existing.remove();
      return;
    }
    this.openPlusMenu(triggerEl);
  }
  openPlusMenu(triggerEl) {
    const doc = this.containerEl.ownerDocument;
    const win = doc.defaultView;
    doc.querySelectorAll(".cfo-plus-menu").forEach((el) => el.remove());
    const popup = doc.body.createDiv({ cls: "cfo-plus-menu" });
    const rect = triggerEl.getBoundingClientRect();
    popup.style.bottom = `${win.innerHeight - rect.top + 6}px`;
    popup.style.left = `${Math.max(8, rect.left)}px`;
    const rows = [
      { icon: "paperclip", label: "Add files or photos", comingSoon: "Attach files. Coming soon." },
      { icon: "folder", label: "Add folder", comingSoon: "Attach a folder. Coming soon." },
      { icon: "slash", label: "Slash commands", action: () => this.openSlashPalette() }
    ];
    for (const r of rows) {
      const row = popup.createDiv({ cls: "cfo-plus-menu-row" });
      const iconEl = row.createSpan({ cls: "cfo-plus-menu-icon" });
      (0, import_obsidian3.setIcon)(iconEl, r.icon);
      row.createSpan({ cls: "cfo-plus-menu-label", text: r.label });
      row.onclick = (e) => {
        e.stopPropagation();
        triggerEl.removeClass("cfo-btn-active");
        popup.remove();
        if (r.action)
          r.action();
        else if (r.comingSoon)
          new import_obsidian3.Notice(r.comingSoon);
      };
    }
    const margin = 8;
    const maxLeft = win.innerWidth - popup.offsetWidth - margin;
    if (popup.offsetLeft > maxLeft) {
      popup.style.left = `${Math.max(margin, maxLeft)}px`;
    }
    triggerEl.addClass("cfo-btn-active");
    const dismiss = (e) => {
      if (popup.contains(e.target))
        return;
      if (triggerEl.contains(e.target))
        return;
      triggerEl.removeClass("cfo-btn-active");
      popup.remove();
      doc.removeEventListener("mousedown", dismiss, true);
      doc.removeEventListener("keydown", esc, true);
    };
    const esc = (e) => {
      if (e.key === "Escape") {
        triggerEl.removeClass("cfo-btn-active");
        popup.remove();
        doc.removeEventListener("mousedown", dismiss, true);
        doc.removeEventListener("keydown", esc, true);
      }
    };
    setTimeout(() => {
      doc.addEventListener("mousedown", dismiss, true);
      doc.addEventListener("keydown", esc, true);
    }, 0);
  }
  /** Context-window popup anchored above the battery ring. Shows
   *  exact tokens used / tokens max / percentage plus a "X remaining"
   *  headline. Data comes from the CLI's `get_context_usage` control
   *  request — authoritative, not the heuristic accumulator that
   *  drives the ring between turns. Falls back to a static cold-open
   *  shape when no session is live. */
  toggleContextPopup() {
    const existing = this.containerEl.ownerDocument.querySelector(
      ".cfo-plan-popup"
    );
    if (existing) {
      const prev = existing.cfoTriggerEl;
      if (prev)
        prev.removeClass("cfo-btn-active");
      existing.remove();
      return;
    }
    this.openContextPopup();
  }
  openContextPopup() {
    const doc = this.containerEl.ownerDocument;
    const win = doc.defaultView;
    doc.querySelectorAll(".cfo-plan-popup").forEach((el) => el.remove());
    const popup = doc.body.createDiv({ cls: "cfo-plan-popup cfo-context-popup" });
    popup.cfoTriggerEl = this.batteryEl;
    const rect = this.batteryEl.getBoundingClientRect();
    popup.style.bottom = `${win.innerHeight - rect.top + 6}px`;
    popup.style.left = "0px";
    popup.createDiv({ cls: "cfo-plan-popup-title", text: "Context window" });
    const body = popup.createDiv({ cls: "cfo-context-body" });
    this.paintContextBody(body, "initial");
    const margin = 8;
    const maxLeft = win.innerWidth - popup.offsetWidth - margin;
    const clamped = Math.max(margin, Math.min(rect.left, maxLeft));
    popup.style.left = `${clamped}px`;
    this.batteryEl.addClass("cfo-btn-active");
    const dismiss = (e) => {
      if (popup.contains(e.target))
        return;
      if (this.batteryEl.contains(e.target))
        return;
      this.batteryEl.removeClass("cfo-btn-active");
      popup.remove();
      doc.removeEventListener("mousedown", dismiss, true);
    };
    setTimeout(() => doc.addEventListener("mousedown", dismiss, true), 0);
    if (this.currentSession?.isAlive) {
      this.currentSession.getContextUsage().then((snapshot) => {
        if (!popup.isConnected)
          return;
        this.paintContextBody(body, "live", snapshot);
      }).catch(() => {
      });
    }
  }
  /** Paint the body of the context-window popup. Two shapes:
   *
   *  - `initial` — use the heuristic accumulator + per-model window.
   *    Renders immediately, no async wait. Used as the first frame
   *    and as the cold-open fallback when no session is live.
   *  - `live`    — use the authoritative `get_context_usage` snapshot.
   *    Replaces the initial frame once the round-trip lands.
   */
  paintContextBody(host, mode, snapshot) {
    const max = mode === "live" && snapshot ? snapshot.maxTokens : contextWindowForModel(this.plugin.settings.model);
    const used = mode === "live" && snapshot ? snapshot.totalTokens : this.sessionTokensUsed;
    const remaining = Math.max(0, max - used);
    const pct = mode === "live" && snapshot ? snapshot.percentage : Math.max(0, Math.min(100, Math.round(used / max * 100)));
    host.empty();
    host.createDiv({
      cls: "cfo-context-headline",
      text: `${this.formatTokens(remaining)} remaining`
    });
    host.createDiv({
      cls: "cfo-context-subline",
      text: `${this.formatTokens(used)} / ${this.formatTokens(max)} used \xB7 ${pct}%`
    });
    const bar = host.createDiv({ cls: "cfo-context-bar" });
    const fill = bar.createDiv({ cls: "cfo-context-bar-fill" });
    fill.style.width = `${pct}%`;
    if (mode === "initial" && !this.currentSession?.isAlive) {
      host.createDiv({
        cls: "cfo-context-note",
        text: "Estimated from this chat's traffic. Send a message to load the live snapshot."
      });
    }
  }
  /** Refresh the context popup body in place if it's open. Called
   *  from the `result` event handler so the numbers update across
   *  turns without re-clicking the battery. */
  refreshContextPopupIfOpen() {
    const popup = this.containerEl.ownerDocument.querySelector(
      ".cfo-context-popup"
    );
    if (!popup)
      return;
    const body = popup.querySelector(".cfo-context-body");
    if (!body)
      return;
    if (!this.currentSession?.isAlive)
      return;
    this.currentSession.getContextUsage().then((snapshot) => {
      if (!popup.isConnected)
        return;
      this.paintContextBody(body, "live", snapshot);
    }).catch(() => {
    });
  }
  /**
   * Toggle a small info popup anchored above the given trigger element.
   * Same contract as the plan-usage popup: click trigger to open, click
   * trigger again to close, click outside to dismiss. Used by the
   * battery (plan usage) and the bottom-nav placeholder buttons.
   */
  toggleInfoPopup(triggerEl, title, body) {
    const existing = this.containerEl.ownerDocument.querySelector(
      ".cfo-plan-popup"
    );
    if (existing) {
      const prevTrigger = existing.cfoTriggerEl;
      if (prevTrigger)
        prevTrigger.removeClass("cfo-btn-active");
      existing.remove();
      return;
    }
    this.openInfoPopup(triggerEl, title, body);
  }
  openInfoPopup(triggerEl, title, body) {
    const doc = this.containerEl.ownerDocument;
    const win = doc.defaultView;
    doc.querySelectorAll(".cfo-plan-popup").forEach((el) => el.remove());
    const popup = doc.body.createDiv({ cls: "cfo-plan-popup" });
    popup.cfoTriggerEl = triggerEl;
    const rect = triggerEl.getBoundingClientRect();
    popup.style.bottom = `${win.innerHeight - rect.top + 6}px`;
    popup.style.left = "0px";
    popup.createDiv({ cls: "cfo-plan-popup-title", text: title });
    popup.createDiv({ cls: "cfo-plan-popup-body", text: body });
    const margin = 8;
    const desiredLeft = rect.left;
    const maxLeft = win.innerWidth - popup.offsetWidth - margin;
    const clamped = Math.max(margin, Math.min(desiredLeft, maxLeft));
    popup.style.left = `${clamped}px`;
    triggerEl.addClass("cfo-btn-active");
    const dismiss = (e) => {
      if (popup.contains(e.target))
        return;
      if (triggerEl.contains(e.target))
        return;
      triggerEl.removeClass("cfo-btn-active");
      popup.remove();
      doc.removeEventListener("mousedown", dismiss, true);
    };
    setTimeout(() => doc.addEventListener("mousedown", dismiss, true), 0);
  }
  formatTokens(n) {
    if (n >= 1e6)
      return `${(n / 1e6).toFixed(2)}M`;
    if (n >= 1e3)
      return `${(n / 1e3).toFixed(1)}k`;
    return String(n);
  }
  toggleSendStop() {
    if (this.turnBusy) {
      this.cancel();
    } else {
      this.send();
    }
  }
  handleEvent(e) {
    switch (e.kind) {
      case "system": {
        const sid = e.raw.session_id ?? null;
        if (!sid)
          break;
        this.activeSessionId = sid;
        this.plugin.settings.activeSessionId = sid;
        this.plugin.saveSettings();
        this.refreshChatTitle();
        break;
      }
      case "assistant-text":
        if (this.currentToolGroup)
          this.closeToolGroup();
        if (!this.currentAssistant) {
          this.currentAssistant = this.startAssistantBuffer();
        }
        this.currentAssistant.text += e.text;
        this.scheduleAssistantRender(this.currentAssistant);
        break;
      case "tool-use":
        if (this.currentAssistant) {
          this.flushAssistantRender(this.currentAssistant);
        }
        this.currentAssistant = null;
        this.appendToolUse(e.id, e.name, e.input);
        break;
      case "permission-request":
        this.enqueuePermissionRequest(e);
        break;
      case "tool-result":
        this.settleToolResult(e.toolUseId, e.isError, e.content);
        if (e.isError) {
          this.clearStatus();
          this.statusEl.setText(`Tool error.`);
        }
        break;
      case "result": {
        const turnTokens = this.tokensFromUsage(e.raw.usage);
        if (turnTokens > 0) {
          this.sessionTokensUsed = Math.max(this.sessionTokensUsed, turnTokens);
          this.renderBattery();
        }
        this.refreshContextPopupIfOpen();
        if (this.currentAssistant)
          this.flushAssistantRender(this.currentAssistant);
        this.currentAssistant = null;
        this.settleAllPendingTools();
        this.turnBusy = false;
        this.setBusy(false);
        this.setThinking(false);
        break;
      }
      case "stderr":
        this.lastStderr = e.line;
        break;
      case "error":
        new import_obsidian3.Notice(`Claude for Obsidian: ${e.message}`);
        this.clearStatus();
        this.statusEl.setText(`Error: ${e.message}`);
        break;
      case "exit": {
        const hadOutput = !!this.currentAssistant;
        if (this.currentAssistant)
          this.flushAssistantRender(this.currentAssistant);
        this.currentSession = null;
        this.turnBusy = false;
        this.currentAssistant = null;
        this.settleAllPendingTools();
        this.permissionQueue = [];
        this.activePermissionRequest = null;
        this.hidePermissionDialog();
        this.setBusy(false);
        if (e.code !== 0 && e.code !== null && !hadOutput) {
          const detail = this.lastStderr ? ` ${this.lastStderr.slice(0, 200)}` : "";
          new import_obsidian3.Notice(`Claude for Obsidian exited (${e.code}).${detail}`);
        }
        this.lastStderr = null;
        break;
      }
    }
  }
};
_ClaudeForObsidianView.TOOL_MIN_VISIBLE_MS = 600;
var ClaudeForObsidianView = _ClaudeForObsidianView;

// src/main.ts
var COMMON_CLAUDE_PATHS = [
  "/opt/homebrew/bin/claude",
  "/usr/local/bin/claude",
  `${process.env.HOME ?? ""}/.npm-global/bin/claude`,
  `${process.env.HOME ?? ""}/.volta/bin/claude`,
  `${process.env.HOME ?? ""}/.bun/bin/claude`
];
var ClaudeForObsidianPlugin = class extends import_obsidian4.Plugin {
  async onload() {
    await this.loadSettings();
    await this.ensureClaudeBinaryPath();
    this.registerView(CLAUDE_FOR_OBSIDIAN_VIEW, (leaf) => new ClaudeForObsidianView(leaf, this));
    this.addRibbonIcon("bot", "Open Claude for Obsidian", () => this.activateView());
    this.addCommand({
      id: "open-claude-for-obsidian",
      name: "Open Claude for Obsidian panel",
      callback: () => this.activateView()
    });
    this.addCommand({
      id: "claude-for-obsidian-new-chat",
      name: "New chat",
      callback: () => this.withView((v) => v.newChat())
    });
    this.addCommand({
      id: "claude-for-obsidian-delete-current-chat",
      name: "Delete current chat",
      callback: () => this.withView((v) => v.deleteCurrentChat())
    });
    this.addCommand({
      id: "claude-for-obsidian-save-chat",
      name: "Save chat to vault",
      callback: () => this.withView((v) => v.saveChatToVault())
    });
    this.addSettingTab(new ClaudeForObsidianSettingTab(this.app, this));
  }
  withView(fn) {
    const leaves = this.app.workspace.getLeavesOfType(CLAUDE_FOR_OBSIDIAN_VIEW);
    if (leaves.length === 0) {
      this.activateView().then(() => {
        const after = this.app.workspace.getLeavesOfType(CLAUDE_FOR_OBSIDIAN_VIEW);
        if (after.length > 0 && after[0].view instanceof ClaudeForObsidianView) {
          fn(after[0].view);
        }
      });
      return;
    }
    if (leaves[0].view instanceof ClaudeForObsidianView) {
      fn(leaves[0].view);
    }
  }
  async onunload() {
  }
  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  /**
   * Resolve the claude binary path on first run or whenever the saved path
   * no longer points at an executable file. Order: saved path (if valid) →
   * `which claude` via login shell → common install locations. If none
   * resolve, leave the default in place and surface a Notice telling the
   * user to run `which claude` themselves.
   */
  async ensureClaudeBinaryPath() {
    const current = this.settings.claudeBinaryPath;
    if (current && fs3.existsSync(current))
      return;
    const detected = this.detectClaudeBinary();
    if (detected) {
      this.settings.claudeBinaryPath = detected;
      await this.saveSettings();
      return;
    }
    new import_obsidian4.Notice(
      "Claude for Obsidian: could not find the claude CLI. Run `which claude` in a terminal and paste the result into Settings \u2192 Claude for Obsidian \u2192 Claude binary path.",
      1e4
    );
  }
  detectClaudeBinary() {
    const shell = process.env.SHELL || "/bin/zsh";
    try {
      const out = (0, import_child_process2.execSync)(`${shell} -lic 'command -v claude'`, {
        encoding: "utf8",
        stdio: ["ignore", "pipe", "ignore"],
        timeout: 3e3
      }).trim().split("\n").pop();
      if (out && fs3.existsSync(out))
        return out;
    } catch {
    }
    for (const candidate of COMMON_CLAUDE_PATHS) {
      if (candidate && fs3.existsSync(candidate))
        return candidate;
    }
    return null;
  }
  async activateView() {
    const { workspace } = this.app;
    const existing = workspace.getLeavesOfType(CLAUDE_FOR_OBSIDIAN_VIEW);
    if (existing.length > 0) {
      workspace.revealLeaf(existing[0]);
      return;
    }
    const leaf = workspace.getRightLeaf(false);
    if (!leaf)
      return;
    await leaf.setViewState({ type: CLAUDE_FOR_OBSIDIAN_VIEW, active: true });
    workspace.revealLeaf(leaf);
  }
};
